# -*- coding: utf-8 -*-
"""Context menu entries of the home screen tiles (kodi.context.item in addon.xml).

Kodi shows the context menu entries a plugin gives its list items only in the video window, not for the tiles of
the skin's home screen; these global entries cover the tiles (addon.xml shows them only on the home screen and only
for PucekCinema items, the lists keep their own entries).
"""
import sys
from urllib.parse import urlsplit

import xbmc

from .utils import ADDON_ID, build_url, parse_params


def mark(played):
    """Jellyfin: mark the tile's item watched / unwatched (the plugin's own mark action does the work)."""
    path = sys.listitem.getPath()
    if not path.startswith(f'plugin://{ADDON_ID}/'):
        return
    item_id = parse_params(urlsplit(path).query).get('id')
    if item_id:
        xbmc.executebuiltin(f"RunPlugin({build_url(action='mark_played' if played else 'mark_unplayed', id=item_id)})")
