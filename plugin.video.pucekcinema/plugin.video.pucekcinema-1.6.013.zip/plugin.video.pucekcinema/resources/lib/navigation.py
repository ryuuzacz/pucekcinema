# -*- coding: utf-8 -*-
"""Directory listings: main menu (the user's Jellyfin libraries), library submenus, series -> seasons -> episodes, search."""
import os
import time
import unicodedata
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlsplit

import xbmc
import xbmcgui
import xbmcplugin

from . import config, focus, fuzzy, rowcache
from .jellyfin_api import JellyfinError
from .listitems import build_item, rich_label, sample_languages
from .utils import (ADDON_FANART, ADDON_ICON, ADDON_ID, ADDON_PATH, DASH_PROPERTY, DASH_ROWS, LISTED_PROPERTY, MEDIA_DIR,
                    build_url, log, notify, parse_params, tr)

# Jellyfin library types that are not video
EXCLUDED_TYPES = ('music', 'musicvideos', 'books', 'photos', 'playlists', 'livetv', 'boxsets')

# How a library is shown: submenu for movies or TV shows, or plain folder browsing.
# 'auto' follows the library type in Jellyfin; the user can override it per library in settings.
LIBRARY_MODES = ('movie', 'series', 'folder')
MODE_LABELS = {'movie': 30173, 'series': 30174, 'folder': 30175}

# Own artwork for libraries with these names (lowercase, without diacritics and spaces):
# image, row icon, label of the "all" entry (None = default by kind)
NAMED_SECTIONS = {
    'filmy': ('filmy.jpg', 'DefaultMovies.png', None),
    'serialy': ('serialy.jpg', 'DefaultTVShows.png', None),
    'anime': ('anime.jpg', 'DefaultFolder.png', 30038),
    'animefilmy': ('animefilmy.jpg', 'DefaultFolder.png', 30039),
}

# settings `sort_order` index -> (sortBy, sortOrder)
SORTS = [
    ('SortName', 'Ascending'),
    ('DateCreated,SortName', 'Descending,Ascending'),
    ('ProductionYear,SortName', 'Descending,Ascending'),
    ('CommunityRating,SortName', 'Descending,Ascending'),
]

PLAYABLE_TYPES = ('Movie', 'Episode', 'Video', 'MusicVideo')

# Library submenu by kind: (entry, label, icon); every entry but 'all' can be hidden in settings (menu_<entry>)
SECTION_MENUS = {
    'Movie': [('watched', 30030, 'DefaultInProgressShows.png'), ('new', 30031, 'DefaultRecentlyAddedMovies.png'),
              ('genres', 30033, 'DefaultGenre.png'), ('letters', 30034, 'DefaultMovieTitle.png'),
              ('all', 30035, 'DefaultMovies.png'), ('search', 30037, 'DefaultAddonsSearch.png')],
    'Series': [('watched', 30030, 'DefaultInProgressShows.png'), ('new', 30031, 'DefaultTVShows.png'),
               ('episodes', 30032, 'DefaultRecentlyAddedEpisodes.png'), ('genres', 30033, 'DefaultGenre.png'),
               ('letters', 30034, 'DefaultTVShowTitle.png'), ('all', 30036, 'DefaultTVShows.png'),
               ('search', 30037, 'DefaultAddonsSearch.png')],
}
SEARCH_KIND_OF = {'Movie': 'movie', 'Series': 'series'}
LATEST_VIEWS = ('watched', 'new', 'episodes')
LETTERS = ['#'] + list('ABCČDEFGHIJKLMNOPQRŘSŠTUVWXYZŽ')

# PucekCinema skin: dashboard rows per library (view, header label); the skin shows up to five
# The skin's dashboard, the same for every film / series library (like Jellyfin's home): Continue watching and
# Next up over all libraries, then "Recently added in <library>" for each of them. Folder libraries show their
# own content instead (one row, header = library name).
DASHBOARD = [('continue', 30040), ('nextup', 30042)]
CONTINUE_TYPES = 'Movie,Episode,Video'
WIDGET_VIEWS = ('continue', 'nextup', 'latest', 'folder')
# Kodi's own entries at the end of the skin's main menu: (id, Kodi string, icon, Estuary rows group)
KODI_MENU = [('addons', 24001, 'icons/sidemenu/addons.png', '8000'),
             ('video', 3, 'icons/sidemenu/videos.png', '11000'),
             ('favorites', 10134, 'icons/sidemenu/favourites.png', '14000')]
KODI_WINDOWS = {'addons': 'ActivateWindow(1100)', 'video': 'ActivateWindow(Videos,root)',
                'favorites': 'ActivateWindow(favouritesbrowser)'}
WIDGET_LIMIT = 20
# rows only need what a tile shows: no cast, no stream details (much smaller and faster answers)
WIDGET_FIELDS = 'Overview,Genres,ProviderIds,DateCreated'
# skin side menu icons (Estuary textures) by library mode
SKIN_WIDGET_GROUP = '1000'  # control id of the rows group in the skin's Home.xml
MENU_ICONS = {'movie': 'icons/sidemenu/movies.png', 'series': 'icons/sidemenu/tv.png',
              'folder': 'icons/sidemenu/pucek-folder.png'}  # made by tools/build_skin.py (menu-sized folder)
SEARCH_MENU_ICON = 'icons/sidemenu/pucek-search.png'  # made by tools/build_skin.py (menu-sized magnifier)
# search kind -> (menu label, type label, Jellyfin item types, icon); 'all' = the global search (main menu, skin
# menu) through every library of the user, 'movie' / 'series' = search inside one library
SEARCH_KINDS = {
    'all': (30000, 30000, 'Movie,Series,Video', 'DefaultAddonsSearch.png'),
    'movie': (30019, 30011, 'Movie', 'DefaultMovies.png'),
    'series': (30020, 30012, 'Series', 'DefaultTVShows.png'),
}


def auto_mode(view):
    return {'movies': 'movie', 'tvshows': 'series'}.get((view.get('CollectionType') or '').lower(), 'folder')


def video_views(client):
    """The user's video libraries in Jellyfin order; Jellyfin applies the user's permissions."""
    return [v for v in client.views() if (v.get('CollectionType') or '').lower() not in EXCLUDED_TYPES]


def _plain(text):
    text = unicodedata.normalize('NFKD', text or '').encode('ascii', 'ignore').decode('ascii')
    return ''.join(text.lower().split())


class Navigator(object):

    def __init__(self, handle, client, state):
        self.handle = handle
        self.client = client
        self.state = state
        self.show_watched = config.show_watched()
        self._sections = None
        self.widget_mode = False  # skin rows: plain labels, no dialogs or notifications
        self.widget_view = None   # the skin row being listed (widget_mode)
        self.focus_id = None      # item to select once Kodi shows the listing (open_item)

    # --- libraries of the logged-in user ---

    def sections(self):
        """The user's video libraries in Jellyfin order; Jellyfin applies the user's permissions."""
        if self._sections is None:
            modes = self.state.library_modes()
            self._sections = {v['Id']: self._describe(v, modes.get(v['Id']) or auto_mode(v))
                              for v in video_views(self.client)}
        return self._sections

    def _describe(self, view, mode):
        if mode == 'movie':
            kind, types = 'Movie', 'Movie'
        elif mode == 'series':
            kind, types = 'Series', 'Series'
        else:
            kind, types = 'Movie', 'Movie,Series,Video'
        named = NAMED_SECTIONS.get(_plain(view.get('Name')))
        if named:
            image, icon, all_label = os.path.join(MEDIA_DIR, named[0]), named[1], named[2]
        else:
            tag = (view.get('ImageTags') or {}).get('Primary')
            image = self.client.image_url(view['Id'], 'Primary', tag, 1280) if tag else ADDON_FANART
            icon, all_label = 'DefaultFolder.png', None
        return {'id': view['Id'], 'name': view.get('Name') or '', 'kind': kind, 'types': types,
                'image': image, 'icon': icon, 'menu': mode != 'folder', 'all_label': all_label, 'mode': mode}

    def section(self, library_id):
        return self.sections().get(library_id)

    # --- helpers ---

    def _add(self, url, list_item, folder):
        xbmcplugin.addDirectoryItem(self.handle, url, list_item, isFolder=folder)

    def _end(self, content=None):
        if content:
            xbmcplugin.setContent(self.handle, content)
        # Explicit '%L': the default mask shows the bare title and would hide our formatted labels.
        try:
            xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_UNSORTED, labelMask='%L', label2Mask='%D')
        except TypeError:
            xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_UNSORTED)
        if not self.widget_mode:  # the service skips its refresh after playback when Kodi already reloaded us
            xbmcgui.Window(10000).setProperty(LISTED_PROPERTY, repr(time.time()))
        xbmcplugin.endOfDirectory(self.handle, cacheToDisc=False)
        if self.focus_id:
            focus.request(self.focus_id)  # the service selects it once Kodi shows the list

    def _fail(self):
        xbmcplugin.endOfDirectory(self.handle, succeeded=False, cacheToDisc=False)

    def _add_items(self, items, episode_label=None):
        """Adds media items labelled 'Name - languages (year) genre' (parts per settings)."""
        if self.widget_mode:
            for item in items:
                # skin tiles: the show title is the caption's second line
                self._add_media_item(item, _episode_code(item) if item.get('Type') == 'Episode' else None)
            return
        languages = {}
        if config.label_part('languages'):
            parents = [i['Id'] for i in items if i.get('Type') in ('Series', 'Season')]
            if parents:
                languages = sample_languages(self.client, parents)
        for item in items:
            self._add_media_item(item, _label(item, languages, episode_label))

    def _add_media_item(self, item, label=None):
        kind = item.get('Type')
        list_item = build_item(self.client, item, label, self.show_watched)
        if not self.widget_mode:
            # lists; the home screen tiles get the same entries from addon.xml (kodi.context.item), once
            played = (item.get('UserData') or {}).get('Played')
            mark = build_url(action='mark_unplayed' if played else 'mark_played', id=item['Id'])
            list_item.addContextMenuItems([(tr(30233 if played else 30232), f'RunPlugin({mark})')])
        if kind == 'Series':
            self._add(build_url(action='series', id=item['Id']), list_item, True)
        elif kind == 'Season':
            self._add(build_url(action='episodes', series=item.get('SeriesId'), season=item['Id']), list_item, True)
        elif kind in PLAYABLE_TYPES and self._opens_in_list():
            self._add(build_url(action='open', id=item['Id']), list_item, True)
        elif kind in PLAYABLE_TYPES:
            list_item.setProperty('IsPlayable', 'true')
            # skin row tiles: Kodi before 21 starts them without its resume dialog, playback asks (skin=1)
            url = build_url(action='play', id=item['Id'], skin=1 if self.widget_mode else None)
            self._add(url, list_item, False)
        elif item.get('IsFolder'):
            if self.widget_mode:  # home screen row: a folder is just the folder icon, never its artwork
                list_item = xbmcgui.ListItem(item.get('Name') or '', offscreen=True)
                list_item.setArt({'icon': 'DefaultFolder.png', 'thumb': 'DefaultFolder.png'})
            else:
                list_item.setArt({'icon': 'DefaultFolder.png'})
            self._add(build_url(action='folder', id=item['Id']), list_item, True)

    def _opens_in_list(self):
        """Skin row tile opening the list holding it (settings); Continue watching always plays."""
        return self.widget_mode and self.widget_view != 'continue' and config.row_click() == config.ROW_OPEN

    def _add_next_page(self, result, page, size, **params):
        total = int(result.get('TotalRecordCount') or 0)
        pages = (total + size - 1) // size
        if page + 1 < pages:
            list_item = xbmcgui.ListItem(tr(30006).format(page + 2, pages), offscreen=True)
            list_item.setArt({'icon': 'DefaultFolder.png'})
            list_item.setProperty('SpecialSort', 'bottom')
            self._add(build_url(page=page + 1, **params), list_item, True)

    def _folder(self, label, url, icon, image):
        list_item = xbmcgui.ListItem(label, offscreen=True)
        list_item.setArt({'icon': icon, 'poster': image})  # default background
        self._add(url, list_item, True)

    # --- routes ---

    # --- PucekCinema skin: main menu and dashboard rows ---

    def section_url(self, section):
        if section['menu']:
            return build_url(action='section', section=section['id'])
        return build_url(action='folder', id=section['id'])

    def home_menu(self, token=''):
        """Main menu of the PucekCinema skin: the user's libraries with their dashboard rows, then Kodi's
        Add-ons, Videos and Favourites (one menu like Estuary's).

        Item properties for the skin: id (pucek / pucek_login / addons / video / favorites), menu_id
        (rows group), widget<N>_path / widget<N>_label (N = 1..5, only rows that have something to show).
        """
        config.publish_home_tiles()
        if not self.client.token:
            list_item = xbmcgui.ListItem(tr(30005), offscreen=True)
            list_item.setArt({'thumb': 'icons/settings/profiles.png'})
            list_item.setProperty('id', 'pucek_login')
            self._add(build_url(action='login'), list_item, True)
            _publish_dashboard([])
        else:
            self.client.fields = WIDGET_FIELDS
            sections = list(self.sections().values())
            rows = self._rows_with_items(sections, token)
            _publish_dashboard([(build_url(action='widget', section=key, view=view), label)
                                for key, view, label in rows if view != 'folder'])
            folder_rows = {key: label for key, view, label in rows if view == 'folder'}
            for section in sections:
                # default background (Estuary's), the library's own picture stays in the add-on's menus
                list_item = xbmcgui.ListItem(section['name'], offscreen=True)
                list_item.setArt({'thumb': MENU_ICONS[section['mode']]})
                list_item.setProperty('id', 'pucek')
                list_item.setProperty('mode', section['mode'])  # folder libraries: their row, not the dashboard
                list_item.setProperty('menu_id', SKIN_WIDGET_GROUP)
                if section['id'] in folder_rows:
                    list_item.setProperty('widget1_path', build_url(action='widget', section=section['id'], view='folder'))
                    list_item.setProperty('widget1_label', folder_rows[section['id']])
                self._add(self.section_url(section), list_item, True)
            list_item = xbmcgui.ListItem(tr(30016), offscreen=True)
            list_item.setArt({'thumb': SEARCH_MENU_ICON})
            list_item.setProperty('id', 'pucek_search')
            list_item.setProperty('menu_id', SKIN_WIDGET_GROUP)  # the dashboard is shown here too
            self._add(build_url(action='search'), list_item, True)
        # PucekCinema settings between the libraries and Kodi's entries; named and drawn differently from
        # Kodi's settings (gear in the top bar), Kodi's own settings are a button inside
        list_item = xbmcgui.ListItem(tr(30239), offscreen=True)
        list_item.setArt({'thumb': 'icons/sidemenu/programs.png'})
        list_item.setProperty('id', 'pucek_settings')
        if self.client.token:
            list_item.setProperty('menu_id', SKIN_WIDGET_GROUP)
        self._add(build_url(action='settings'), list_item, True)
        for item_id, label_id, icon, menu_id in KODI_MENU:
            list_item = xbmcgui.ListItem(xbmc.getLocalizedString(label_id), offscreen=True)
            list_item.setArt({'thumb': icon})
            list_item.setProperty('id', item_id)
            list_item.setProperty('menu_id', menu_id)
            self._add(build_url(action='kodi', target=item_id), list_item, True)
        xbmcplugin.endOfDirectory(self.handle, cacheToDisc=False)

    def _rows_with_items(self, sections, token):
        """[(library id or 'all', view, header)] of the rows that are not empty, dashboard rows first (no empty
        gaps). Loads every row once, in parallel, and keeps it in the row cache for the skin's row requests."""
        checks = [('all', view, None, tr(label_id)) for view, label_id in DASHBOARD]
        checks += [(s['id'], 'latest', s, tr(30277).format(s['name'])) for s in sections if s['mode'] != 'folder']
        checks += [(s['id'], 'folder', s, s['name']) for s in sections if s['mode'] == 'folder']

        def has_items(check):
            key, view, section = check[:3]
            cached = rowcache.load(self.client.user_id, key, view, token)
            if cached is not None:
                return bool(cached['items'])
            try:
                items = self._row_items(section, view, WIDGET_LIMIT)
            except JellyfinError:
                return False
            rowcache.save(self.client.user_id, key, view, token, items, _row_content(section, view))
            return bool(items)

        with ThreadPoolExecutor(max_workers=8) as pool:
            results = list(pool.map(has_items, checks))
        return [(key, view, label) for (key, view, _, label), ok in zip(checks, results) if ok]

    def _row_items(self, section, view, limit):
        """Items of a row: `section` is the library (latest, folder) or None (continue, next up: all libraries)."""
        if view == 'folder':
            return self.client.items(parentId=section['id'], sortBy='IsFolder,SortName',
                                     sortOrder='Descending,Ascending', limit=limit).get('Items') or []
        if view == 'continue':  # films, episodes and videos (a folder library switched to films) watched halfway
            items = self.client.items(includeItemTypes=CONTINUE_TYPES, recursive=True, filters='IsResumable',
                                      sortBy='DatePlayed', sortOrder='Descending', limit=limit).get('Items') or []
        elif view == 'nextup':
            # Jellyfin's next up also lists an episode watched halfway; that one is in Continue watching
            items = [e for e in self.client.next_up(None, limit)
                     if not (e.get('UserData') or {}).get('PlaybackPositionTicks')]
        elif view == 'latest':
            return self.client.latest(section['id'], limit)
        else:
            return []
        allowed = self._in_media_libraries(view)
        return [i for i in items if i.get('Id') in allowed]

    def _in_media_libraries(self, view):
        """Ids of the continue / next up items of the film and series libraries, asked library by library: the
        dashboard never shows anything of the folder libraries (private videos and the like). The rows keep the
        order of Jellyfin's list over all libraries; asking for ids inside a library does not work (Jellyfin then
        ignores the library)."""
        allowed = set()
        for section in self.sections().values():
            if section['mode'] == 'folder':
                continue
            if view == 'continue':
                found = self.client.items(parentId=section['id'], includeItemTypes=CONTINUE_TYPES, recursive=True,
                                          filters='IsResumable', limit=100).get('Items') or []
            else:
                found = self.client.next_up(section['id'], 100)
            allowed.update(i.get('Id') for i in found)
        return allowed

    def widget(self, library_id, view, token=''):
        """One dashboard row: quiet (no dialogs), plain labels; from the row cache when it is fresh."""
        self.widget_mode = True
        self.widget_view = view
        self.client.fields = WIDGET_FIELDS
        cached = rowcache.load(self.client.user_id, library_id, view, token)
        if cached is None:
            section = None if library_id == 'all' else self.section(library_id)
            if section and (view == 'folder') != (section['mode'] == 'folder'):
                section = None  # a row of the library's previous type, asked once more by the skin: empty
            if section or (library_id == 'all' and view in ('continue', 'nextup')):
                items, content = self._row_items(section, view, WIDGET_LIMIT), _row_content(section, view)
                rowcache.save(self.client.user_id, library_id, view, token, items, content)
            else:
                items, content = [], 'videos'
            cached = {'items': items, 'content': content}
        self._add_items(cached['items'])
        self._end(cached['content'])

    def main_menu(self):
        settings = build_url(action='settings')
        if not self.client.token:
            self._folder(tr(30005), build_url(action='login'), 'DefaultUser.png', ADDON_ICON)
            self._folder(tr(30018), settings, 'DefaultAddonService.png', ADDON_ICON)
            xbmcplugin.endOfDirectory(self.handle, cacheToDisc=False)
            return
        # Row shows the icon; the info panel (poster) and background (fanart) show the artwork.
        self._folder(tr(30000), build_url(action='search'), 'DefaultAddonsSearch.png', ADDON_ICON)
        for section in self.sections().values():
            if section['menu']:
                url = build_url(action='section', section=section['id'])
            else:
                url = build_url(action='folder', id=section['id'])
            self._folder(section['name'], url, section['icon'], section['image'])
        self._folder(tr(30018), settings, 'DefaultAddonService.png', ADDON_ICON)
        xbmcplugin.endOfDirectory(self.handle, cacheToDisc=False)

    def section_menu(self, library_id):
        section = self.section(library_id)
        if not section:
            self._fail()
            return
        if not section['menu']:
            self.folder(library_id)
            return
        for entry, label_id, icon in SECTION_MENUS[section['kind']]:
            if entry != 'all' and not config.menu_enabled(entry):
                continue
            if entry == 'all' and section['all_label']:
                label_id = section['all_label']
            if entry == 'search':
                url = build_url(action='search_kind', kind=SEARCH_KIND_OF[section['kind']], section=library_id)
            elif entry in ('genres', 'letters'):
                url = build_url(action=entry, section=library_id)
            else:
                url = build_url(action='list', section=library_id, view=entry)
            self._folder(tr(label_id), url, icon, section['image'])
        self._end()

    def latest(self, library_id, view):
        """Top-N lists: recently watched, new, newest episodes."""
        section = self.section(library_id)
        if not section:
            self._fail()
            return
        if view == 'watched':
            items = self._recently_watched(section, config.limit('watched'))
        elif view == 'episodes':
            items = self._newest(library_id, 'Episode', config.limit('episodes'))
        else:
            items = self._newest(library_id, section['types'], config.limit('new'))
        if not items:
            notify(tr(30014))
        self._add_items(items, _episode_label)
        if view == 'episodes':
            self._end('episodes')
        else:
            self._end('movies' if section['kind'] == 'Movie' else 'tvshows')

    def _newest(self, library_id, item_types, count):
        return self.client.items(parentId=library_id, includeItemTypes=item_types, recursive=True,
                                 sortBy='DateCreated', sortOrder='Descending', limit=count).get('Items') or []

    def _played(self, library_id, item_types, count):
        """Played items (watched to the end or halfway), last played first."""
        result = self.client.items(parentId=library_id, includeItemTypes=item_types, recursive=True,
                                   sortBy='DatePlayed', sortOrder='Descending', limit=count)
        return [i for i in result.get('Items') or [] if (i.get('UserData') or {}).get('LastPlayedDate')]

    def _recently_watched(self, section, count):
        """The library menu's Naposledy sledované: films / shows last played, in progress ones too; a show once,
        in the order of its last played episode."""
        if section['kind'] == 'Movie':
            return self._played(section['id'], section['types'], count)
        series_ids = []
        for episode in self._played(section['id'], 'Episode', min(count * 5, 200)):
            if episode.get('SeriesId') and episode['SeriesId'] not in series_ids:
                series_ids.append(episode['SeriesId'])
        series_ids = series_ids[:count]
        if not series_ids:
            return []
        found = {i['Id']: i for i in self.client.items(ids=','.join(series_ids)).get('Items') or []}
        return [found[i] for i in series_ids if i in found]

    def genres(self, library_id):
        section = self.section(library_id)
        if not section:
            self._fail()
            return
        genres = self.client.genres(library_id, section['types'])
        for genre in sorted(genres, key=lambda g: (g.get('Name') or '').lower()):
            url = build_url(action='list', section=library_id, view='genre', genre=genre['Id'])
            self._folder(genre.get('Name') or '', url, 'DefaultGenre.png', section['image'])
        self._end()

    def letters(self, library_id):
        section = self.section(library_id)
        if not section:
            self._fail()
            return
        for letter in LETTERS:
            url = build_url(action='list', section=library_id, view='letter', letter=letter)
            self._folder(letter, url, 'DefaultFolder.png', section['image'])
        self._end()

    def paged(self, library_id, view, page=0, genre=None, letter=None):
        """Paged lists: all, genre (newest first), first letter."""
        section = self.section(library_id)
        if not section:
            self._fail()
            return
        if view == 'genre':
            query = {'genreIds': genre, 'sortBy': 'DateCreated,SortName', 'sortOrder': 'Descending,Ascending'}
        elif view == 'letter':
            query = {'sortBy': 'SortName', 'sortOrder': 'Ascending'}
            query.update({'nameLessThan': 'A'} if letter == '#' else {'nameStartsWith': letter})
        else:
            sort_by, sort_order = _sort()
            query = {'sortBy': sort_by, 'sortOrder': sort_order}

        size = config.page_size()
        result = self.client.items(parentId=library_id, includeItemTypes=section['types'], recursive=True,
                                   startIndex=page * size, limit=size, enableTotalRecordCount=True, **query)
        self._add_items(result.get('Items') or [])
        self._add_next_page(result, page, size, action='list', section=library_id, view=view,
                            genre=genre, letter=letter)
        self._end('movies' if section['kind'] == 'Movie' else 'tvshows')

    def folder(self, folder_id, page=0):
        """Plain folder browsing (libraries shown as folders): subfolders first, then the content."""
        size = config.page_size()
        result = self.client.items(parentId=folder_id, sortBy='IsFolder,SortName', sortOrder='Descending,Ascending',
                                   startIndex=page * size, limit=size, enableTotalRecordCount=True)
        self._add_items(result.get('Items') or [])
        self._add_next_page(result, page, size, action='folder', id=folder_id)
        self._end('videos')

    def open_item(self, item_id):
        """Skin row tile (settings: open in the list): the page of the list holding the film / episode / video,
        focused on it - all films of its library, the episodes of its season, or its folder."""
        found = self.client.items(ids=item_id, fields='ParentId').get('Items') or []
        if not found:
            self._fail()
            return
        item, size = found[0], config.page_size()
        self.focus_id = item_id
        light = {'fields': '', 'enableUserData': False}
        if item.get('Type') == 'Episode' and item.get('SeriesId'):
            episodes = self.client.episodes(item['SeriesId'], item.get('SeasonId')).get('Items') or []
            self.episodes(item['SeriesId'], item.get('SeasonId'), _page_of(episodes, item_id, size))
            return
        ancestors = {a.get('Id') for a in self.client.ancestors(item_id)}
        library = next((s for s in self.sections().values() if s['id'] in ancestors), None)
        if library and library['mode'] != 'folder':
            sort_by, sort_order = _sort()
            items = self.client.items(parentId=library['id'], includeItemTypes=library['types'], recursive=True,
                                      sortBy=sort_by, sortOrder=sort_order, **light).get('Items') or []
            self.paged(library['id'], 'all', _page_of(items, item_id, size))
        elif item.get('ParentId'):
            items = self.client.items(parentId=item['ParentId'], sortBy='IsFolder,SortName',
                                      sortOrder='Descending,Ascending', **light).get('Items') or []
            self.folder(item['ParentId'], _page_of(items, item_id, size))
        else:
            self._fail()

    def series(self, series_id):
        seasons = self.client.seasons(series_id)
        if not seasons or (len(seasons) == 1 and config.skip_single_season()):
            self.episodes(series_id, seasons[0]['Id'] if seasons else None)
            return
        self._add_items(seasons)
        self._end('seasons')

    def episodes(self, series_id, season_id=None, page=0):
        size = config.page_size()
        result = self.client.episodes(series_id, season_id, start=page * size, limit=size)
        self._add_items(result.get('Items') or [])
        self._add_next_page(result, page, size, action='episodes', series=series_id, season=season_id)
        self._end('episodes')

    # --- search ---

    def _search_libraries(self, kind):
        """Libraries of the user that contain the searched type (movie libraries for films, ...); all of them
        for the global search."""
        if kind == 'all':
            return list(self.sections())
        item_type = SEARCH_KINDS[kind][2]
        return [s['id'] for s in self.sections().values() if item_type in s['types'].split(',')]

    def _search_history(self, kind, section):
        """Last searches shown under 'Search': of this kind and library; the global search lists every search made
        outside a library (also the older film / TV show searches), each query once, at most 20."""
        if kind != 'all':
            return [e for e in self.state.search_history() if e['kind'] == kind and e.get('section') == section]
        entries, seen = [], set()
        for entry in self.state.search_history():
            if entry.get('section') is None and entry['q'].lower() not in seen:
                seen.add(entry['q'].lower())
                entries.append(entry)
        return entries[:config.SEARCH_HISTORY_SIZE]

    def search_kind(self, kind, section=None):
        """'Search' on top (opens the keyboard), below the last searches of this kind (and library)."""
        icon = SEARCH_KINDS[kind][3]
        library = self.section(section) if section else None
        image = library['image'] if library else ADDON_ICON
        self._folder(tr(30016), build_url(action='search_new', kind=kind, section=section),
                     'DefaultAddonsSearch.png', image)
        for entry in self._search_history(kind, section):
            query = entry['q']
            list_item = xbmcgui.ListItem(query, offscreen=True)
            list_item.setArt({'icon': icon, 'poster': image})
            remove = build_url(action='search_remove', q=query, kind=entry['kind'], section=section)
            list_item.addContextMenuItems([(tr(30017), f'RunPlugin({remove})')])
            self._add(build_url(action='search_results', q=query, kind=kind, section=section), list_item, True)
        self._end()

    def search_new(self, kind, section=None):
        # Kodi re-runs this URL when the user comes Back from a result; only a click in a
        # search menu ('Search' above the history) opens the keyboard, otherwise the last
        # search of this kind and library is shown again.
        came_from = xbmc.getInfoLabel('Container.FolderPath')
        from_menu = (came_from.startswith(f'plugin://{ADDON_ID}')
                     and parse_params(urlsplit(came_from).query).get('action') in ('search', 'search_kind'))
        history = [e['q'] for e in self._search_history(kind, section)]
        if from_menu or not history:
            keyboard = xbmc.Keyboard('', tr(SEARCH_KINDS[kind][0]))
            keyboard.doModal()
            query = keyboard.getText().strip() if keyboard.isConfirmed() else ''
        else:
            query = history[0]
        if not query:
            self._fail()
            return
        self.state.add_search(query, kind, section)
        self.search_results(query, kind, section)

    def search_results(self, query, kind, section=None):
        """Searches one library, all of the user's libraries holding `kind`, or every library ('all').

        Jellyfin's exact matches come first, then titles that are only similar (typos, missing diacritics).
        """
        item_type = SEARCH_KINDS[kind][2]
        library_ids = ([section] if self.section(section) else []) if section else self._search_libraries(kind)
        size = config.page_size()
        found = {}
        for library_id in library_ids:
            result = self.client.items(searchTerm=query, parentId=library_id, includeItemTypes=item_type,
                                       recursive=True, limit=size)
            for item in result.get('Items') or []:
                found.setdefault(item['Id'], item)
        exact = len(found)
        if config.fuzzy_search() and len(found) < size:
            similar = fuzzy.search(self.client, library_ids, item_type, query, size - len(found), exclude=found)
            if similar:
                by_id = {i['Id']: i for i in self.client.items(ids=','.join(similar)).get('Items') or []}
                for item_id in similar:
                    if item_id in by_id:
                        found[item_id] = by_id[item_id]
        log(f'Search {kind} "{query}": {exact} exact, {len(found) - exact} similar', xbmc.LOGINFO)
        if not found:
            notify(tr(30014))
        self._add_items(list(found.values()))
        self._end({'Movie': 'movies', 'Series': 'tvshows'}.get(item_type, 'videos'))


def _sort():
    """(sortBy, sortOrder) of the 'all' lists, from the settings."""
    index = config.sort_order()
    return SORTS[index] if 0 <= index < len(SORTS) else SORTS[0]


def _page_of(items, item_id, size):
    ids = [i.get('Id') for i in items]
    return ids.index(item_id) // size if item_id in ids else 0


def _row_content(section, view):
    if view in ('folder', 'continue'):
        return 'videos'
    if view == 'nextup':
        return 'episodes'
    return 'movies' if section['kind'] == 'Movie' else 'tvshows'


def _publish_dashboard(rows):
    """Paths and headers of the dashboard rows for the skin (Home window properties); the rest emptied."""
    home = xbmcgui.Window(10000)
    for number in range(1, DASH_ROWS + 1):
        path, label = rows[number - 1] if number <= len(rows) else ('', '')
        home.setProperty(f'{DASH_PROPERTY}{number}_path', path)
        home.setProperty(f'{DASH_PROPERTY}{number}_label', label)


def _episode_code(item):
    """'S01E03 - Name' (always, also inside a season)."""
    season, number = item.get('ParentIndexNumber'), item.get('IndexNumber')
    name = item.get('Name') or ''
    if number is None:
        return name
    code = f'S{season:02d}E{number:02d}' if season is not None else f'E{number:02d}'
    return f'{code} - {name}'


def _episode_label(item):
    """'Show - S01E03 - Name' for lists mixing several shows."""
    return f"{item.get('SeriesName') or ''} - {_episode_code(item)}"


def _label(item, languages, episode_label=None):
    kind = item.get('Type')
    if kind == 'Movie':
        return rich_label(item)
    if kind == 'Series':
        return rich_label(item, languages.get(item['Id'], ''))
    if kind == 'Season':
        base = item.get('Name') or tr(30007).format(item.get('IndexNumber'))
        return rich_label(item, languages.get(item['Id'], ''), base=base, genre=False)
    if kind == 'Episode':
        base = (episode_label or _episode_code)(item)
        return rich_label(item, base=base, year=False, genre=False)
    return None


def _mode_text(view, mode):
    if mode:
        return tr(MODE_LABELS[mode])
    return tr(30172).format(tr(MODE_LABELS[auto_mode(view)]))


# Typy knihoven dialog (resources/skins/default/1080i/script-pucekcinema-librarymodes.xml)
MODES_HEADER, MODES_LIST, MODES_SAVE, MODES_CANCEL = 1, 3, 201, 202  # the ids of Estuary's select dialog
CLOSE_ACTIONS = (9, 10, 92)  # parent dir, previous menu, back


class LibraryModesDialog(xbmcgui.WindowXMLDialog):
    """Estuary's select dialog: the user's libraries with their type (a click picks another type), Save and Cancel
    in the button column on the right.
    Built through WindowXMLDialog.__new__(xml, path, skin, resolution); the base __init__ is not called on purpose."""

    def __init__(self, *args):
        self.views, self.modes, self.saved = [], {}, False

    def onInit(self):
        self.getControl(MODES_HEADER).setLabel(tr(30170))
        self._fill(0)
        self.setFocusId(MODES_LIST)

    def _fill(self, position):
        control = self.getControl(MODES_LIST)
        control.reset()
        # 'Filmy  (Automaticky (Filmové zobrazení))' like Kodi's select dialogs (one line per library)
        control.addItems([xbmcgui.ListItem(f"{v.get('Name') or ''}  [I]({_mode_text(v, self.modes.get(v['Id']))})[/I]",
                                           offscreen=True) for v in self.views])
        control.selectItem(position)

    def onClick(self, control_id):
        if control_id == MODES_LIST:
            index = self.getControl(MODES_LIST).getSelectedPosition()
            if 0 <= index < len(self.views):
                self._choose(index)
        elif control_id in (MODES_SAVE, MODES_CANCEL):
            self.saved = control_id == MODES_SAVE
            self.close()

    def onAction(self, action):
        if action.getId() in CLOSE_ACTIONS:
            self.close()

    def _choose(self, index):
        view = self.views[index]
        current = self.modes.get(view['Id'])
        options = [_mode_text(view, None)] + [tr(MODE_LABELS[m]) for m in LIBRARY_MODES]
        preselect = LIBRARY_MODES.index(current) + 1 if current in LIBRARY_MODES else 0
        choice = xbmcgui.Dialog().select(tr(30176).format(view.get('Name')), options, preselect=preselect)
        if choice > 0:
            self.modes[view['Id']] = LIBRARY_MODES[choice - 1]
        elif choice == 0:
            self.modes.pop(view['Id'], None)
        self._fill(index)


def choose_library_modes(client, state):
    """Settings button Typy knihoven: how each of the user's libraries is shown (automatic / films / TV shows /
    folder). Saved only with Save; Cancel or Back drops the changes. Returns True when saved."""
    views = video_views(client)
    if not views:
        notify(tr(30222), error=True)
        return False
    dialog = LibraryModesDialog('script-pucekcinema-librarymodes.xml', ADDON_PATH, 'default', '1080i')
    dialog.views, dialog.modes = views, state.library_modes()
    dialog.doModal()
    saved, modes = dialog.saved, dialog.modes
    del dialog
    if saved:
        state.set_library_modes(modes)
    return saved

