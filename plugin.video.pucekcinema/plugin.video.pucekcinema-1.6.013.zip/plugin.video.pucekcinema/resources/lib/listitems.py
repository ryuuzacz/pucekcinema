# -*- coding: utf-8 -*-
"""Jellyfin item -> Kodi ListItem (metadata and artwork), shared by navigation and playback."""
import json
import os
import re
import time
from concurrent.futures import ThreadPoolExecutor

import xbmc
import xbmcgui

from . import config
from .jellyfin_api import TICKS_PER_SECOND, JellyfinError
from .utils import PROFILE_DIR, log

LANGUAGE_CACHE = os.path.join(PROFILE_DIR, 'languages.json')
LANGUAGE_CACHE_TTL = 7 * 24 * 3600

POSTER_WIDTH = 500
FANART_WIDTH = 1280
THUMB_WIDTH = 720

MEDIA_TYPES = {'Movie': 'movie', 'Series': 'tvshow', 'Season': 'season', 'Episode': 'episode'}

# Jellyfin ISO 639-2 stream language -> short label in the listing
LANGUAGE_LABELS = {
    'cze': 'CZ', 'ces': 'CZ', 'slo': 'SK', 'slk': 'SK', 'eng': 'EN', 'ger': 'DE', 'deu': 'DE',
    'fre': 'FR', 'fra': 'FR', 'spa': 'ES', 'ita': 'IT', 'rus': 'RU', 'pol': 'PL', 'hun': 'HU',
    'jpn': 'JP', 'kor': 'KO', 'chi': 'ZH', 'zho': 'ZH', 'hin': 'HI', 'dan': 'DA', 'swe': 'SV',
    'nor': 'NO', 'fin': 'FI', 'dut': 'NL', 'nld': 'NL', 'por': 'PT', 'ukr': 'UK', 'tur': 'TR',
}
# Subtitles in these languages mark a foreign audio track as "+tit"
NATIVE_LANGUAGES = ('CZ', 'SK')


def _language_label(code):
    code = (code or '').lower()
    if not code or code in ('und', 'unknown', 'mis', 'zxx'):
        return None
    return LANGUAGE_LABELS.get(code, code[:2].upper())


def language_summary(item):
    """'CZ, EN, EN+tit': audio languages in track order, foreign ones also with Czech/Slovak subtitles."""
    streams = item.get('MediaStreams') or ((item.get('MediaSources') or [{}])[0].get('MediaStreams') or [])
    audio = []
    for stream in streams:
        label = _language_label(stream.get('Language')) if stream.get('Type') == 'Audio' else None
        if label and label not in audio:
            audio.append(label)
    native_subtitles = any(stream.get('Type') == 'Subtitle' and _language_label(stream.get('Language')) in NATIVE_LANGUAGES
                           for stream in streams)
    parts = []
    for label in audio:
        parts.append(label)
        if native_subtitles and label not in NATIVE_LANGUAGES:
            parts.append(label + '+tit')
    return ', '.join(parts)


def sample_languages(client, parent_ids):
    """{series or season id: 'CZ, EN'} from one sample episode each, fetched in parallel and cached on disk."""
    try:
        with open(LANGUAGE_CACHE, 'r', encoding='utf-8') as handle:
            cache = json.load(handle)
    except (OSError, ValueError):
        cache = {}
    now = time.time()
    result, missing = {}, []
    for parent_id in parent_ids:
        entry = cache.get(parent_id)
        if entry and now - entry[1] < LANGUAGE_CACHE_TTL:
            result[parent_id] = entry[0]
        else:
            missing.append(parent_id)
    if not missing:
        return result

    def fetch(parent_id):
        try:
            episode = client.sample_episode(parent_id)
        except JellyfinError:
            return parent_id, None
        return parent_id, language_summary(episode) if episode else ''

    with ThreadPoolExecutor(max_workers=8) as pool:
        for parent_id, languages in pool.map(fetch, missing):
            if languages is not None:
                result[parent_id] = languages
                cache[parent_id] = [languages, now]
    cache = {k: v for k, v in cache.items() if now - v[1] < LANGUAGE_CACHE_TTL}
    try:
        os.makedirs(PROFILE_DIR, exist_ok=True)
        with open(LANGUAGE_CACHE, 'w', encoding='utf-8') as handle:
            json.dump(cache, handle)
    except OSError as exc:
        log(f'Cannot write language cache: {exc}')
    return result


def rich_label(item, languages=None, base=None, year=True, genre=True):
    """'Name - [B]CZ, EN+tit[/B] (2025) [I]Drama[/I]'; each part can be switched off in settings.

    `languages` overrides the item's own streams (series and seasons have none, a sample episode is used).
    """
    label = base if base is not None else item.get('Name') or ''
    if config.label_part('languages'):
        languages = language_summary(item) if languages is None else languages
        if languages:
            label += f' - [B]{languages}[/B]'
    if year and config.label_part('year') and item.get('ProductionYear'):
        label += f" ({item['ProductionYear']})"
    if genre and config.label_part('genre') and item.get('Genres'):
        label += f" [I]{item['Genres'][0]}[/I]"
    return label


def build_art(client, item):
    art = {}
    item_id = item['Id']
    kind = item.get('Type')
    tags = item.get('ImageTags') or {}

    if 'Primary' in tags:
        if kind == 'Episode':
            art['thumb'] = client.image_url(item_id, 'Primary', tags['Primary'], THUMB_WIDTH)
        else:
            art['poster'] = art['thumb'] = client.image_url(item_id, 'Primary', tags['Primary'], POSTER_WIDTH)
    if item.get('SeriesId') and item.get('SeriesPrimaryImageTag'):
        series_poster = client.image_url(item['SeriesId'], 'Primary', item['SeriesPrimaryImageTag'], POSTER_WIDTH)
        art['tvshow.poster'] = series_poster
        art.setdefault('poster', series_poster)
        art.setdefault('thumb', series_poster)

    backdrops = item.get('BackdropImageTags') or []
    if backdrops:
        art['fanart'] = client.image_url(item_id, 'Backdrop', backdrops[0], FANART_WIDTH, 0)
    elif item.get('ParentBackdropItemId') and item.get('ParentBackdropImageTags'):
        art['fanart'] = client.image_url(item['ParentBackdropItemId'], 'Backdrop',
                                         item['ParentBackdropImageTags'][0], FANART_WIDTH, 0)

    if 'Thumb' in tags:
        art['landscape'] = client.image_url(item_id, 'Thumb', tags['Thumb'], THUMB_WIDTH)
    elif item.get('ParentThumbItemId') and item.get('ParentThumbImageTag'):
        art['landscape'] = client.image_url(item['ParentThumbItemId'], 'Thumb', item['ParentThumbImageTag'], THUMB_WIDTH)
    elif item.get('SeriesId') and item.get('SeriesThumbImageTag'):
        art['landscape'] = client.image_url(item['SeriesId'], 'Thumb', item['SeriesThumbImageTag'], THUMB_WIDTH)
    elif art.get('fanart'):  # landscape tiles (skin): the backdrop when there is no Thumb image
        art['landscape'] = art['fanart']
    elif kind == 'Episode' and 'thumb' in art:  # episode still
        art['landscape'] = art['thumb']

    if 'Logo' in tags:
        art['clearlogo'] = client.image_url(item_id, 'Logo', tags['Logo'], POSTER_WIDTH)
    elif item.get('ParentLogoItemId') and item.get('ParentLogoImageTag'):
        art['clearlogo'] = client.image_url(item['ParentLogoItemId'], 'Logo', item['ParentLogoImageTag'], POSTER_WIDTH)
    return art


# setInfo key -> InfoTagVideo setter (Kodi 20+); Kodi 19 only understands setInfo.
INFO_SETTERS = {
    'mediatype': 'setMediaType', 'title': 'setTitle', 'originaltitle': 'setOriginalTitle',
    'sorttitle': 'setSortTitle', 'plot': 'setPlot', 'tagline': 'setTagLine', 'year': 'setYear',
    'premiered': 'setPremiered', 'aired': 'setFirstAired', 'dateadded': 'setDateAdded', 'mpaa': 'setMpaa',
    'genre': 'setGenres', 'studio': 'setStudios', 'country': 'setCountries', 'tag': 'setTags',
    'director': 'setDirectors', 'writer': 'setWriters', 'duration': 'setDuration', 'trailer': 'setTrailer',
    'tvshowtitle': 'setTvShowTitle', 'status': 'setTvShowStatus', 'season': 'setSeason', 'episode': 'setEpisode',
    'imdbnumber': 'setIMDBNumber', 'playcount': 'setPlaycount',
}

CAST_LIMIT = 30
CAST_TYPES = ('Actor', 'GuestStar')
HDR_TYPES = {'HDR10': 'hdr10', 'HDR10Plus': 'hdr10', 'HLG': 'hlg', 'DOVI': 'dolbyvision',
             'DOVIWithHDR10': 'dolbyvision', 'DOVIWithHLG': 'dolbyvision', 'DOVIWithSDR': 'dolbyvision'}
YOUTUBE_ID = re.compile(r'(?:v=|youtu\.be/|/embed/)([\w-]{11})')


def _people(item, kind):
    return [p for p in item.get('People') or [] if p.get('Type') == kind and p.get('Name')]


def _trailer(item):
    for trailer in item.get('RemoteTrailers') or []:
        match = YOUTUBE_ID.search(trailer.get('Url') or '')
        if match:
            return f'plugin://plugin.video.youtube/play/?video_id={match.group(1)}'
    return None


def item_info(item, show_watched=True):
    kind = item.get('Type')
    info = {'mediatype': MEDIA_TYPES.get(kind, 'video'), 'title': item.get('Name') or ''}
    if item.get('OriginalTitle') and item['OriginalTitle'] != item.get('Name'):
        info['originaltitle'] = item['OriginalTitle']
    if item.get('SortName'):
        info['sorttitle'] = item['SortName']
    if item.get('Overview'):
        info['plot'] = item['Overview']
    if item.get('Taglines'):
        info['tagline'] = item['Taglines'][0]
    if item.get('ProductionYear'):
        info['year'] = int(item['ProductionYear'])
    premiered = (item.get('PremiereDate') or '')[:10]
    if premiered:
        info['premiered'] = premiered
        if kind == 'Episode':
            info['aired'] = premiered
    if item.get('DateCreated'):
        info['dateadded'] = item['DateCreated'][:19].replace('T', ' ')
    if item.get('OfficialRating'):
        info['mpaa'] = item['OfficialRating']
    if item.get('Genres'):
        info['genre'] = list(item['Genres'])
    studios = [s.get('Name') for s in item.get('Studios') or [] if s.get('Name')]
    if studios:
        info['studio'] = studios
    if item.get('ProductionLocations'):
        info['country'] = list(item['ProductionLocations'])
    if item.get('Tags'):
        info['tag'] = list(item['Tags'])
    directors = [p['Name'] for p in _people(item, 'Director')]
    if directors:
        info['director'] = directors
    writers = [p['Name'] for p in _people(item, 'Writer')]
    if writers:
        info['writer'] = writers
    if item.get('RunTimeTicks'):
        info['duration'] = int(item['RunTimeTicks'] // TICKS_PER_SECOND)
    trailer = _trailer(item)
    if trailer:
        info['trailer'] = trailer

    if kind == 'Series':
        info['tvshowtitle'] = item.get('Name') or ''
        if item.get('Status'):
            info['status'] = item['Status']
    elif kind in ('Season', 'Episode') and item.get('SeriesName'):
        info['tvshowtitle'] = item['SeriesName']
    if kind == 'Episode':
        if item.get('ParentIndexNumber') is not None:
            info['season'] = int(item['ParentIndexNumber'])
        if item.get('IndexNumber') is not None:
            info['episode'] = int(item['IndexNumber'])
    elif kind == 'Season' and item.get('IndexNumber') is not None:
        info['season'] = int(item['IndexNumber'])

    if show_watched:
        user_data = item.get('UserData') or {}
        if user_data.get('Played'):
            info['playcount'] = max(1, int(user_data.get('PlayCount') or 1))
    return info


def _cast(client, item):
    people = [p for p in item.get('People') or [] if p.get('Type') in CAST_TYPES and p.get('Name')]
    cast = []
    for order, person in enumerate(people[:CAST_LIMIT]):
        thumb = ''
        if client and person.get('Id') and person.get('PrimaryImageTag'):
            thumb = client.image_url(person['Id'], 'Primary', person['PrimaryImageTag'], 300)
        cast.append({'name': person['Name'], 'role': person.get('Role') or '', 'order': order, 'thumbnail': thumb})
    return cast


def _audio_codec(stream):
    codec = (stream.get('Codec') or '').lower()
    profile = (stream.get('Profile') or '').upper()
    if codec == 'dts' and 'MA' in profile:
        return 'dtshd_ma'
    if codec == 'dts' and 'HR' in profile:
        return 'dtshd_hra'
    return codec


def stream_details(item):
    """Kodi stream info (resolution, codecs, channels, HDR, languages) for the media flags."""
    streams = item.get('MediaStreams') or ((item.get('MediaSources') or [{}])[0].get('MediaStreams') or [])
    duration = int(item['RunTimeTicks'] // TICKS_PER_SECOND) if item.get('RunTimeTicks') else 0
    video, audio, subtitles = [], [], []
    for stream in streams:
        kind = stream.get('Type')
        if kind == 'Video' and not video:
            width, height = int(stream.get('Width') or 0), int(stream.get('Height') or 0)
            video.append({'codec': (stream.get('Codec') or '').lower(), 'width': width, 'height': height,
                          'aspect': round(width / height, 2) if width and height else 0.0, 'duration': duration,
                          'language': stream.get('Language') or '',
                          'hdrtype': HDR_TYPES.get(stream.get('VideoRangeType') or '', '')})
        elif kind == 'Audio':
            audio.append({'codec': _audio_codec(stream), 'channels': int(stream.get('Channels') or 0),
                          'language': stream.get('Language') or ''})
        elif kind == 'Subtitle':
            subtitles.append({'language': stream.get('Language') or ''})
    return video, audio, subtitles


def _properties(item):
    """Series/season episode counters used by skins (watched progress)."""
    kind = item.get('Type')
    props = {}
    if kind == 'Series' and item.get('ChildCount') is not None:
        props['TotalSeasons'] = item['ChildCount']
    total = item.get('RecursiveItemCount')
    if kind in ('Series', 'Season') and total is not None:
        unwatched = int((item.get('UserData') or {}).get('UnplayedItemCount') or 0)
        props.update(TotalEpisodes=total, UnWatchedEpisodes=unwatched, WatchedEpisodes=max(0, total - unwatched))
    return {k: str(v) for k, v in props.items()}


def resume_point(item):
    """(position, total) in seconds from Jellyfin; Kodi then offers "Resume from ..." itself (one dialog)
    and skins show the in-progress state. None when there is nothing to resume."""
    ticks = int((item.get('UserData') or {}).get('PlaybackPositionTicks') or 0)
    total = int(item.get('RunTimeTicks') or 0)
    if not ticks or not total or not config.resume_from_jellyfin():
        return None
    return float(ticks // TICKS_PER_SECOND), float(total // TICKS_PER_SECOND)


def apply_info(list_item, item, show_watched=True, client=None):
    info = item_info(item, show_watched)
    ids = {k.lower(): str(v) for k, v in (item.get('ProviderIds') or {}).items() if v}
    default_id = 'tmdb' if 'tmdb' in ids else ('imdb' if 'imdb' in ids else next(iter(ids), None))
    if 'imdb' in ids:
        info['imdbnumber'] = ids['imdb']
    ratings = []
    if item.get('CommunityRating'):
        ratings.append(('default', float(item['CommunityRating']), True))
    if item.get('CriticRating'):
        ratings.append(('tomatometerallcritics', float(item['CriticRating']) / 10, not ratings))
    cast = _cast(client, item)
    playable = item.get('Type') in ('Movie', 'Episode', 'Video')
    video, audio, subtitles = stream_details(item) if playable else ([], [], [])
    resume = resume_point(item) if show_watched and playable else None

    tag = list_item.getVideoInfoTag()
    if hasattr(tag, 'setMediaType'):
        for key, value in info.items():
            getattr(tag, INFO_SETTERS[key])(value)
        if ids:
            tag.setUniqueIDs(ids, default_id)
        for name, value, default in ratings:
            tag.setRating(value, 0, name, default)
        if cast:
            tag.setCast([xbmc.Actor(c['name'], c['role'], c['order'], c['thumbnail']) for c in cast])
        for v in video:
            tag.addVideoStream(xbmc.VideoStreamDetail(width=v['width'], height=v['height'], aspect=v['aspect'],
                                                      duration=v['duration'], codec=v['codec'],
                                                      language=v['language'], hdrtype=v['hdrtype']))
        for a in audio:
            tag.addAudioStream(xbmc.AudioStreamDetail(channels=a['channels'], codec=a['codec'], language=a['language']))
        for s in subtitles:
            tag.addSubtitleStream(xbmc.SubtitleStreamDetail(language=s['language']))
        if resume:
            tag.setResumePoint(*resume)
    else:
        list_item.setInfo('video', info)
        if ids:
            list_item.setUniqueIDs(ids, default_id)
        for name, value, default in ratings:
            list_item.setRating(name, value, 0, default)
        if cast:
            list_item.setCast(cast)
        for v in video:
            list_item.addStreamInfo('video', v)
        for a in audio:
            list_item.addStreamInfo('audio', a)
        for s in subtitles:
            list_item.addStreamInfo('subtitle', s)
        if resume:
            list_item.setProperty('ResumeTime', str(resume[0]))
            list_item.setProperty('TotalTime', str(resume[1]))

    for key, value in _properties(item).items():
        list_item.setProperty(key, value)


def build_item(client, item, label=None, show_watched=True):
    list_item = xbmcgui.ListItem(label or item.get('Name') or '', offscreen=True)
    apply_info(list_item, item, show_watched, client)
    list_item.setArt(build_art(client, item))
    return list_item
