# -*- coding: utf-8 -*-
"""Disk cache of the skin's home screen rows.

Kodi runs the plugin for every row each time the focused library changes; without the cache each of
those runs asked Jellyfin again. The home menu fills the cache for all libraries at once (in parallel),
rows then read it. An entry is valid for ROW_TTL seconds and only for the same reload token: the skin
puts the token into the row URLs and it changes after playback, marking watched and login.
"""
import json
import os
import re
import shutil
import time

from .utils import ADDON_VERSION, PROFILE_DIR, save_json

ROW_DIR = os.path.join(PROFILE_DIR, 'rows')
ROW_TTL = 600


def _path(user_id, library_id, view):
    name = re.sub(r'[^\w-]', '', f'{user_id}_{library_id}_{view}')
    return os.path.join(ROW_DIR, f'{name}.json')


def load(user_id, library_id, view, token):
    """{'items': [...], 'content': ...} or None when missing, stale or from an older reload token."""
    try:
        with open(_path(user_id, library_id, view), 'r', encoding='utf-8') as handle:
            entry = json.load(handle)
    except (OSError, ValueError):
        return None
    if entry.get('token') != token or entry.get('version') != ADDON_VERSION \
            or time.time() - entry.get('time', 0) > ROW_TTL:  # a newer add-on may build its rows differently
        return None
    return entry


def clear():
    shutil.rmtree(ROW_DIR, ignore_errors=True)


def save(user_id, library_id, view, token, items, content):
    save_json(_path(user_id, library_id, view),
              {'time': time.time(), 'token': token, 'version': ADDON_VERSION, 'items': items, 'content': content})
