# -*- coding: utf-8 -*-
"""The PucekCinema skin's dashboard rows, prepared by the service.

Every row of the skin is a plugin run of its own, and Kodi starts only a few at a time: when each of them asked
Jellyfin, the dashboard filled row by row for many seconds after every change. The service (always running)
loads all rows at once instead, in parallel, into the row cache, and publishes their paths with a digest of
their content: a row request then only reads a file, and Kodi reloads only the rows whose content changed.

It does so at start, after every reload of the skin's rows (playback, marking, favourites, settings, login) and
every REBUILD_EVERY seconds (newly added films and episodes).
"""
import threading
import time

import xbmc
import xbmcgui

from . import config
from .jellyfin_api import JellyfinError
from .utils import MENU_RELOAD_PROPERTY, WIDGET_RELOAD_PROPERTY, log

REBUILD_EVERY = 900


def build():
    """Loads and publishes the rows (the service's thread). Kept as they were when Jellyfin is out of reach."""
    from .navigation import Navigator, publish_dashboard
    started = time.time()
    state = config.State()
    client = config.get_client(state)
    if not client.token:
        publish_dashboard(None)
        return
    stamp = xbmcgui.Window(10000).getProperty(MENU_RELOAD_PROPERTY)  # settings, login, library types
    try:
        rows = Navigator(-1, client, state).dashboard_rows(stamp)
    except JellyfinError as exc:
        log(f'Dashboard rows not prepared: {exc}', xbmc.LOGWARNING)
        return
    if rows is None:
        log('Dashboard rows not prepared: Jellyfin did not answer', xbmc.LOGWARNING)
        return
    publish_dashboard(rows)
    log(f'Dashboard rows prepared in {time.time() - started:.1f} s', xbmc.LOGINFO)


class DashboardBuilder(object):
    """Service side: step() several times a second; builds in a thread of its own, one build at a time (a change
    during a build is picked up right after it)."""

    def __init__(self):
        self.seen, self.built_at, self.thread = None, 0.0, None

    def step(self):
        if self.thread and self.thread.is_alive():
            return
        home = xbmcgui.Window(10000)
        token = (home.getProperty(WIDGET_RELOAD_PROPERTY), home.getProperty(MENU_RELOAD_PROPERTY))
        due = token != self.seen or (time.time() - self.built_at > REBUILD_EVERY and not xbmc.Player().isPlaying())
        if not due:
            return
        self.seen, self.built_at = token, time.time()
        self.thread = threading.Thread(target=_safe_build)
        self.thread.daemon = True
        self.thread.start()


def _safe_build():
    try:
        build()
    except Exception as exc:  # the service must keep running
        log(f'Dashboard rows failed: {exc!r}', xbmc.LOGERROR)
