# -*- coding: utf-8 -*-
"""Disk cache of the skin's home screen rows.

The service prepares the dashboard rows (all at once, in parallel) and keeps each under a digest of its content,
which is also in the row's URL: the skin's row request then only reads the file, and an entry stays valid as long
as the URL asks for it. Folder rows (filled by the home menu) are keyed by the skin's reload token instead and are
valid for ROW_TTL seconds.
"""
import json
import os
import re
import shutil
import time

from .utils import ADDON_VERSION, PROFILE_DIR, save_json

ROW_DIR = os.path.join(PROFILE_DIR, 'rows')
ROW_TTL = 600


def _path(user_id, library_id, view):
    name = re.sub(r'[^\w-]', '', f'{user_id}_{library_id}_{view}')
    return os.path.join(ROW_DIR, f'{name}.json')


def load(user_id, library_id, view, token, ttl=ROW_TTL):
    """{'items': [...], 'content': ...} or None when missing, stale (ttl None: never) or of another token."""
    try:
        with open(_path(user_id, library_id, view), 'r', encoding='utf-8') as handle:
            entry = json.load(handle)
    except (OSError, ValueError):
        return None
    if entry.get('token') != token or entry.get('version') != ADDON_VERSION \
            or (ttl and time.time() - entry.get('time', 0) > ttl):  # a newer add-on may build its rows differently
        return None
    return entry


def clear():
    shutil.rmtree(ROW_DIR, ignore_errors=True)


def save(user_id, library_id, view, token, items, content):
    save_json(_path(user_id, library_id, view),
              {'time': time.time(), 'token': token, 'version': ADDON_VERSION, 'items': items, 'content': content})
