# -*- coding: utf-8 -*-
"""Minimal Jellyfin REST client (urllib only, no extra Kodi dependencies)."""
import json
import ssl
import unicodedata
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlencode
from urllib.request import Request, urlopen

import xbmc

from . import listcache
from .utils import ADDON_VERSION, log

CLIENT_NAME = 'PucekCinema'
TICKS_PER_SECOND = 10000000

ITEM_FIELDS = ('Overview,Genres,Studios,ProviderIds,DateCreated,MediaStreams,OriginalTitle,SortName,Taglines,'
               'Tags,ProductionLocations,RemoteTrailers,ChildCount,RecursiveItemCount')
PEOPLE_FIELD = 'People'
IMAGE_TYPES = 'Primary,Backdrop,Thumb,Logo'


class JellyfinError(Exception):
    pass


class AuthError(JellyfinError):
    """HTTP 401: wrong credentials or revoked/expired token."""


def _header_value(text):
    # Authorization header values must stay plain ASCII without quotes or commas.
    text = unicodedata.normalize('NFKD', text or '').encode('ascii', 'ignore').decode('ascii')
    return text.replace('"', '').replace(',', ' ').strip() or 'Kodi'


def _query_value(value):
    if value is True:
        return 'true'
    if value is False:
        return 'false'
    return value


class JellyfinClient(object):

    def __init__(self, server, device_id, token=None, user_id=None, verify_ssl=True, timeout=20):
        self.server = server
        self.device_id = device_id
        self.token = token
        self.user_id = user_id
        self.timeout = timeout
        self.fields = ITEM_FIELDS
        self.cache_token = None  # set while browsing: GET answers come from listcache (never for playback)
        self.device_name = _header_value(xbmc.getInfoLabel('System.FriendlyName'))
        self._ssl = None
        if server.lower().startswith('https') and not verify_ssl:
            self._ssl = ssl._create_unverified_context()

    @property
    def authorization(self):
        parts = [('Client', CLIENT_NAME), ('Device', self.device_name),
                 ('DeviceId', self.device_id), ('Version', ADDON_VERSION)]
        if self.token:
            parts.append(('Token', self.token))
        return 'MediaBrowser ' + ', '.join(f'{k}="{v}"' for k, v in parts)

    @property
    def user_agent(self):
        return f'{CLIENT_NAME}/{ADDON_VERSION}'

    def url(self, path, params=None):
        url = self.server + path
        clean = {k: _query_value(v) for k, v in (params or {}).items() if v is not None and v != ''}
        if clean:
            url += '?' + urlencode(clean)
        return url

    def _open(self, method, url, body=None, accept='application/json'):
        headers = {'Authorization': self.authorization, 'Accept': accept, 'User-Agent': self.user_agent}
        data = None
        if body is not None:
            data = json.dumps(body).encode('utf-8')
            headers['Content-Type'] = 'application/json'
        elif method == 'POST':
            data = b''
        request = Request(url, data=data, headers=headers, method=method)
        try:
            with urlopen(request, timeout=self.timeout, context=self._ssl) as response:
                return response.read()
        except HTTPError as exc:
            if exc.code == 401:
                raise AuthError('HTTP 401')
            raise JellyfinError(f'HTTP {exc.code}')
        except (URLError, OSError, ValueError) as exc:
            raise JellyfinError(str(getattr(exc, 'reason', exc)))

    def request(self, method, path, params=None, body=None):
        url = self.url(path, params)
        cache_key = f'{self.user_id}|{url}' if method == 'GET' and self.cache_token is not None else None
        if cache_key:
            cached = listcache.get(cache_key, self.cache_token)
            if cached is not None:
                return cached
        log(f'{method} {path}')
        raw = self._open(method, url, body)
        if not raw:
            return None
        try:
            data = json.loads(raw.decode('utf-8'))
        except ValueError:
            raise JellyfinError('Invalid server response')
        if cache_key:
            listcache.put(cache_key, self.cache_token, data)
        return data

    def get(self, path, **params):
        return self.request('GET', path, params)

    def download(self, url):
        return self._open('GET', url, accept='*/*')

    # --- server and login ---

    def public_info(self):
        return self.get('/System/Info/Public') or {}

    def authenticate_by_name(self, username, password):
        return self.request('POST', '/Users/AuthenticateByName',
                            body={'Username': username, 'Pw': password}) or {}

    def quick_connect_enabled(self):
        try:
            return bool(self.get('/QuickConnect/Enabled'))
        except JellyfinError:
            return False

    def quick_connect_initiate(self):
        return self.request('POST', '/QuickConnect/Initiate') or {}

    def quick_connect_state(self, secret):
        return self.get('/QuickConnect/Connect', secret=secret) or {}

    def authenticate_quick_connect(self, secret):
        return self.request('POST', '/Users/AuthenticateWithQuickConnect', body={'Secret': secret}) or {}

    def logout(self):
        self.request('POST', '/Sessions/Logout')

    # --- library browsing ---

    def _with_defaults(self, params):
        params.setdefault('userId', self.user_id)
        params.setdefault('fields', self.fields)
        params.setdefault('enableImageTypes', IMAGE_TYPES)
        params.setdefault('imageTypeLimit', 1)
        params.setdefault('enableUserData', True)
        return params

    def views(self):
        return (self.get('/UserViews', userId=self.user_id) or {}).get('Items') or []

    def items(self, **params):
        return self.get('/Items', **self._with_defaults(params)) or {}

    def item(self, item_id):
        fields = f'{ITEM_FIELDS},{PEOPLE_FIELD},MediaSources,Path'
        found = self.items(ids=item_id, fields=fields).get('Items') or []
        if not found:
            raise JellyfinError('Item not found')
        return found[0]

    def titles(self, parent_id, item_type):
        """All titles of one type in a library, without images or user data (index for fuzzy search)."""
        result = self.get('/Items', userId=self.user_id, parentId=parent_id, includeItemTypes=item_type,
                          recursive=True, fields='OriginalTitle', enableImages=False, enableUserData=False,
                          enableTotalRecordCount=False) or {}
        return [{'Id': i['Id'], 'Name': i.get('Name') or '', 'OriginalTitle': i.get('OriginalTitle') or ''}
                for i in result.get('Items') or []]

    def latest(self, parent_id, limit, unplayed=False):
        """Jellyfin's "Recently added in ...": newest items of a library, new episodes of one show grouped into
        the show (which then moves to the front). unplayed: watched items left out; otherwise Jellyfin decides by
        the user's own setting (hide played in latest, off by default)."""
        params = {'parentId': parent_id, 'limit': limit, 'isPlayed': False if unplayed else None}
        data = self.get('/Items/Latest', **self._with_defaults(params))
        return data if isinstance(data, list) else []

    def next_up(self, parent_id, limit):
        """Next unwatched episode of each show the user is watching."""
        result = self.get('/Shows/NextUp', **self._with_defaults({'parentId': parent_id, 'limit': limit})) or {}
        return result.get('Items') or []

    def sample_episode(self, parent_id):
        """One episode of a series or season with its streams (to show the show's languages)."""
        result = self.get('/Items', userId=self.user_id, parentId=parent_id, includeItemTypes='Episode',
                          recursive=True, limit=1, fields='MediaStreams', enableImages=False,
                          enableUserData=False) or {}
        items = result.get('Items') or []
        return items[0] if items else None

    def genres(self, parent_id, item_type):
        result = self.get('/Genres', userId=self.user_id, parentId=parent_id, includeItemTypes=item_type,
                          sortBy='SortName', enableImageTypes='Primary') or {}
        return result.get('Items') or []

    def seasons(self, series_id):
        result = self.get(f'/Shows/{series_id}/Seasons', **self._with_defaults({})) or {}
        return result.get('Items') or []

    def episodes(self, series_id, season_id=None, start=0, limit=None):
        params = self._with_defaults({'seasonId': season_id, 'startIndex': start, 'limit': limit})
        return self.get(f'/Shows/{series_id}/Episodes', **params) or {}

    # --- watched state and playback reporting ---

    def set_favorite(self, item_id, favorite):
        """Jellyfin's favourites (the heart): per user, on every device."""
        self.request('POST' if favorite else 'DELETE', f'/UserFavoriteItems/{item_id}', {'userId': self.user_id})

    def set_played(self, item_id, played):
        self.request('POST' if played else 'DELETE', f'/UserPlayedItems/{item_id}', {'userId': self.user_id})

    def ancestors(self, item_id):
        return self.get(f'/Items/{item_id}/Ancestors', userId=self.user_id) or []

    def report_playback(self, event, payload):
        """event: '' (start), 'Progress' or 'Stopped' -> /Sessions/Playing[/event]."""
        self.request('POST', '/Sessions/Playing' + (f'/{event}' if event else ''), body=payload)

    # --- URLs handed to Kodi ---

    def image_url(self, item_id, image_type, tag, max_width, index=None):
        path = f'/Items/{item_id}/Images/{image_type}'
        if index is not None:
            path += f'/{index}'
        return self.url(path, {'tag': tag, 'maxWidth': max_width, 'quality': 90})

    def stream_url(self, item_id, source_id, container=None):
        """Original file as-is (static=true): no transcoding, all audio and subtitle tracks kept."""
        ext = (container or '').split(',')[0].strip()
        path = f'/Videos/{item_id}/stream' + (f'.{ext}' if ext else '')
        return self.url(path, {'static': True, 'mediaSourceId': source_id, 'deviceId': self.device_id})

    def subtitle_url(self, item_id, source_id, index, fmt):
        return self.url(f'/Videos/{item_id}/{source_id}/Subtitles/{index}/Stream.{fmt}')

    def kodi_headers(self):
        """Headers in Kodi's `url|Header=value&...` form."""
        return urlencode({'Authorization': self.authorization, 'User-Agent': self.user_agent}, quote_via=quote)
