# -*- coding: utf-8 -*-
from resources.lib import context

if __name__ == '__main__':
    context.favorite(False)
