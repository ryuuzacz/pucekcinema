# -*- coding: utf-8 -*-
"""Background service: reports Kodi playback to Jellyfin and offers the next episode.

The plugin call that resolves an item only lives for a moment, so it hands the item over to
the service through a Home window property. The service watches Kodi's player and talks to
Jellyfin; Jellyfin itself decides "in progress" vs "watched" from the stop position.

Next episode: shortly before the end (countdown from settings) a small dialog (Continue / Cancel, with countdown) appears;
the next episode is opened while the current one still plays, never from inside Kodi's
end-of-playback callback (doing that can take Kodi down on Android TV).
"""
import json
import time
import uuid

import xbmc
import xbmcgui

from . import config, hdr, languages
from .jellyfin_api import TICKS_PER_SECOND, JellyfinError
from .utils import ADDON_ID, ADDON_PATH, LISTED_PROPERTY, build_url, log, reload_widgets, tr

WINDOW_PROPERTY = f'{ADDON_ID}.playback'
HANDOVER_TIMEOUT = 120
PROGRESS_INTERVAL = 10
MIN_RUNTIME = 60        # no dialog for very short videos
FALLBACK_DELAY = 2      # next episode after a natural end, from the service loop
REFRESH_DELAY = 2       # listing refresh after playback, once Kodi settled
REFRESH_SETTLE = 2      # ... back in the video window and idle for this many service ticks (seconds)
REFRESH_GIVE_UP = 30    # ... or never, when Kodi does not get back to the list in this time

DIALOG_TITLE, DIALOG_EPISODE, BUTTON_PLAY, BUTTON_CANCEL = 3000, 3003, 3001, 3002
CLOSE_ACTIONS = (9, 10, 92)  # parent dir, previous menu, back


def announce(item, source_id, play_method, chain=0, start=0.0):
    """Called by the plugin right before setResolvedUrl. `chain` = episodes started automatically in a row,
    `start` = position chosen in the plugin's own resume dialog (skin tiles on Kodi before 21)."""
    data = {'item_id': item['Id'], 'source_id': source_id, 'method': play_method,
            'session': uuid.uuid4().hex, 'runtime_ticks': int(item.get('RunTimeTicks') or 0),
            'time': time.time(), 'type': item.get('Type'), 'series_id': item.get('SeriesId'),
            'season_id': item.get('SeasonId'), 'chain': int(chain), 'start': float(start or 0)}
    xbmcgui.Window(10000).setProperty(WINDOW_PROPERTY, json.dumps(data))


def take_announcement():
    window = xbmcgui.Window(10000)
    raw = window.getProperty(WINDOW_PROPERTY)
    window.clearProperty(WINDOW_PROPERTY)
    try:
        data = json.loads(raw) if raw else None
    except ValueError:
        return None
    if not data or time.time() - data.get('time', 0) > HANDOVER_TIMEOUT:
        return None
    return data


def episode_title(episode):
    number = episode.get('IndexNumber')
    code = f"S{episode.get('ParentIndexNumber') or 0:02d}E{number:02d} - " if number is not None else ''
    return code + (episode.get('Name') or '')


class NextEpisodeDialog(xbmcgui.WindowXMLDialog):
    """Small non-modal dialog in the top right corner: 'Next episode ... in 10 s' [Continue] [Cancel]."""

    # Built through WindowXMLDialog.__new__(xml, path, skin, resolution); the base __init__ is not called on purpose.
    def __init__(self, *args):
        self.episode = ''
        self.choice = None
        self.ready = False

    def onInit(self):
        self.ready = True
        self.getControl(DIALOG_EPISODE).setLabel(self.episode)
        self.setFocusId(BUTTON_PLAY)

    def countdown(self, seconds):
        if self.ready:
            self.getControl(DIALOG_TITLE).setLabel(tr(30235).format(max(0, int(seconds))))

    def onClick(self, control_id):
        if control_id in (BUTTON_PLAY, BUTTON_CANCEL):
            self.choice = 'play' if control_id == BUTTON_PLAY else 'cancel'
            self.close()

    def onAction(self, action):
        if action.getId() in CLOSE_ACTIONS:
            self.choice = 'cancel'
            self.close()


class PlaybackReporter(xbmc.Player):

    def __init__(self):
        super(PlaybackReporter, self).__init__()
        self.current = None
        self.client = None
        self.position = 0.0
        self.total = 0.0
        self.paused = False
        self.reporting = True
        self.last_report = 0.0
        self.next_episode = None    # episode to offer after the current one
        self.countdown = 30         # seconds before the end the next-episode dialog appears (settings)
        self.dialog = None
        self.pending_next = None    # (url, not before) after a natural end
        self.refresh_at = None
        self.stopped_at = 0.0       # when the stop was reported (listings older than this are stale)
        self.settled = 0            # service ticks Kodi has been idle in the video window

    # --- Kodi player callbacks ---

    def onAVStarted(self):
        info = take_announcement()
        self._close_dialog()
        self.current, self.next_episode, self.pending_next = None, None, None
        if not info:
            hdr.restore()  # someone else's playback: never under PucekCinema's HDR choice
            return
        config.reload()  # the service lives long; pick up settings changed meanwhile
        client = config.get_client(config.State())
        if not client.token:
            return
        self.current, self.client = info, client
        self.reporting = config.report_playback()
        self.position, self.paused = 0.0, False
        self._update_position()
        if info.get('start') and self.position < info['start'] - 10:
            # StartOffset of the resolved item not applied by this Kodi: go to the chosen position
            self.seekTime(info['start'])
            self.position = info['start']
        self.next_episode = self._find_next_episode(info)
        self.countdown = config.autoplay_countdown()
        languages.apply()  # preferred audio / subtitle language (add-on settings)
        self._report('')

    def onPlayBackPaused(self):
        self.paused = True
        self._report('Progress', 'Pause')

    def onPlayBackResumed(self):
        self.paused = False
        self._report('Progress', 'Unpause')

    def onPlayBackSeek(self, seek_time, seek_offset):
        self._update_position()
        self._report('Progress', 'TimeUpdate')

    def onPlayBackStopped(self):
        self._stop(ended=False)

    def onPlayBackEnded(self):
        self._stop(ended=True)

    def onPlayBackError(self):
        self._stop(ended=False)

    # --- service loop (every second) ---

    def tick(self):
        now = time.time()
        if self.pending_next and now >= self.pending_next[1] and not self.isPlaying():
            url, self.pending_next = self.pending_next[0], None
            xbmc.executebuiltin(f'PlayMedia({url})')
        if self.refresh_at and now >= self.refresh_at:
            self._refresh_listing()
        hdr.restore_if_idle(self.isPlaying() or bool(self.pending_next))
        if not self.current:
            return
        self._update_position()
        if not self.paused and now - self.last_report >= PROGRESS_INTERVAL:
            self._report('Progress', 'TimeUpdate')
        self._next_episode_countdown()

    def _update_position(self):
        try:
            if self.isPlayingVideo():
                self.position = self.getTime()
                self.total = self.getTotalTime() or self.total
        except RuntimeError:
            pass

    # --- next episode ---

    def _find_next_episode(self, info):
        if info.get('type') != 'Episode' or not info.get('series_id') or info['chain'] >= config.autoplay_limit():
            return None
        try:
            episodes = self.client.episodes(info['series_id'], info.get('season_id')).get('Items') or []
        except JellyfinError as exc:
            log(f'Next episode lookup failed: {exc}', xbmc.LOGWARNING)
            return None
        ids = [e['Id'] for e in episodes]
        if info['item_id'] not in ids or ids.index(info['item_id']) + 1 >= len(ids):
            return None
        return episodes[ids.index(info['item_id']) + 1]

    @staticmethod
    def _next_url(episode, info):
        return build_url(action='play', id=episode['Id'], autoplay=info['chain'] + 1)

    def _next_episode_countdown(self):
        if not self.next_episode or self.total < MIN_RUNTIME:
            return
        remaining = self.total - self.position
        if self.dialog is None:
            if remaining <= self.countdown:
                self.dialog = NextEpisodeDialog('script-pucekcinema-nextup.xml', ADDON_PATH, 'default', '1080i')
                self.dialog.episode = episode_title(self.next_episode)
                self.dialog.show()
            return
        if self.dialog.choice == 'cancel':
            log('Next episode cancelled by the user', xbmc.LOGINFO)
            self.next_episode = None
            self._close_dialog()
        elif self.dialog.choice == 'play' or remaining <= 1:
            self._start_next_episode()
        elif remaining > self.countdown + 5:  # seeked back: offer again later
            self._close_dialog()
        else:
            self.dialog.countdown(remaining)

    def _start_next_episode(self):
        """Opens the next episode while the current one still plays (no end-of-playback teardown)."""
        url = self._next_url(self.next_episode, self.current)
        log(f"Next episode {self.next_episode['Id']} ({self.current['chain'] + 1}/{config.autoplay_limit()})",
            xbmc.LOGINFO)
        self._close_dialog()
        self._finish(ended=False)
        request = {'jsonrpc': '2.0', 'id': 1, 'method': 'Player.Open',
                   'params': {'item': {'file': url}, 'options': {'resume': False}}}
        xbmc.executeJSONRPC(json.dumps(request))

    def _close_dialog(self):
        if self.dialog is not None:
            try:
                self.dialog.close()
            except RuntimeError:
                pass
            self.dialog = None

    # --- reporting ---

    def _payload(self, position_ticks=None):
        info = self.current
        return {'ItemId': info['item_id'], 'MediaSourceId': info['source_id'], 'PlaySessionId': info['session'],
                'PlayMethod': info['method'], 'CanSeek': True, 'IsPaused': self.paused,
                'PositionTicks': int(self.position * TICKS_PER_SECOND) if position_ticks is None else position_ticks}

    def _report(self, event, event_name=None):
        if not self.current or not self.reporting:
            return
        payload = self._payload()
        if event_name:
            payload['EventName'] = event_name
        self.last_report = time.time()
        try:
            self.client.report_playback(event, payload)
        except JellyfinError as exc:
            log(f'Playback report {event or "Start"} failed: {exc}', xbmc.LOGWARNING)

    def _finish(self, ended):
        """Reports the stop of the current item and forgets it; returns its info."""
        info = self.current
        # After a natural end Kodi no longer knows the time; the full runtime makes Jellyfin mark it watched.
        ticks = info['runtime_ticks'] if ended and info['runtime_ticks'] else None
        if self.reporting:
            try:
                self.client.report_playback('Stopped', self._payload(ticks))
                log(f"Reported stop of {info['item_id']} at {ticks or int(self.position * TICKS_PER_SECOND)} ticks",
                    xbmc.LOGINFO)
            except JellyfinError as exc:
                log(f'Playback stop report failed: {exc}', xbmc.LOGWARNING)
        self.current = None
        reload_widgets()  # continue watching / recently watched rows of the skin
        return info

    def _stop(self, ended):
        if not ended and self.isPlaying():
            return  # the old file's stop while the next one already plays (switch to the next episode)
        self._close_dialog()
        if not self.current:
            return
        info = self._finish(ended)
        if ended and self.next_episode:
            # Ended before the dialog could start it: open it from the service loop after a short pause.
            # HDR stays as it is for the next episode.
            self.pending_next = (self._next_url(self.next_episode, info), time.time() + FALLBACK_DELAY)
        else:
            hdr.restore()
            self.stopped_at = time.time()
            self.refresh_at = self.stopped_at + REFRESH_DELAY
            self.settled = 0
        self.next_episode = None

    def _refresh_listing(self):
        """One refresh of our listing after playback (watched marks, resume points), only once Kodi is back in the
        video window and idle, and only when Kodi did not reload the listing itself after the stop.

        Kodi reloads a plugin listing on its own when it gets back to it; a refresh sent while it does (a TV takes
        a while to leave the player) runs the plugin twice at once for one list, and Kodi then shows an empty list
        with just '..' (or the items twice).
        """
        now = time.time()
        if now - self.stopped_at > REFRESH_GIVE_UP:
            self.refresh_at = None
            return
        busy = (self.isPlaying() or xbmc.getCondVisibility('Container.IsUpdating')
                or not xbmc.getCondVisibility('Window.IsActive(videos)')
                or xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)'))
        self.settled = 0 if busy else self.settled + 1
        if self.settled < REFRESH_SETTLE:
            self.refresh_at = now + 1
            return
        self.refresh_at = None
        if not xbmc.getInfoLabel('Container.FolderPath').startswith(f'plugin://{ADDON_ID}'):
            return
        try:
            listed = float(xbmcgui.Window(10000).getProperty(LISTED_PROPERTY) or 0)
        except ValueError:
            listed = 0.0
        if listed > self.stopped_at:
            log('Listing already reloaded by Kodi after playback, no refresh')
            return
        xbmc.executebuiltin('Container.Refresh')


class SettingsMonitor(xbmc.Monitor):
    """Applies the tile style of the skin's home screen as soon as it is changed in the settings."""

    def onSettingsChanged(self):
        config.reload()
        config.publish_home_tiles()
        reload_widgets()  # rows carry the tile click (play / open in the list) in their item URLs


def run_service():
    monitor = SettingsMonitor()
    config.publish_home_tiles()
    reporter = PlaybackReporter()
    log('Playback reporting service started', xbmc.LOGINFO)
    while not monitor.waitForAbort(1):
        reporter.tick()
