# -*- coding: utf-8 -*-
"""Entry point dispatch: plugin://plugin.video.pucekcinema/?action=..."""
import json

import xbmc
import xbmcgui
import xbmcplugin

from . import auth, config, playback
from .jellyfin_api import AuthError, JellyfinError
from .navigation import KODI_WINDOWS, LATEST_VIEWS, SEARCH_KINDS, WIDGET_VIEWS, Navigator, choose_library_modes
from .utils import (ADDON_ID, ADDON_NAME, WIDGET_RELOAD_PROPERTY, build_url, log, notify, parse_params,
                    reload_widgets, tr)

PUBLIC_ACTIONS = ('main', 'login', 'logout')
# Requested by the PucekCinema skin in the background: never a dialog, failures give an empty list
QUIET_ACTIONS = ('home_menu', 'widget')


def run(argv):
    handle = int(argv[1]) if len(argv) > 1 and argv[1].lstrip('-').isdigit() else -1
    params = parse_params(argv[2] if len(argv) > 2 else '')
    action = params.get('action', 'main')
    state = config.State()
    if action in QUIET_ACTIONS:
        _dispatch_quiet(action, params, handle, state)
        return
    try:
        _dispatch(action, params, handle, state)
    except AuthError:
        log('Token rejected by server', xbmc.LOGWARNING)
        state.clear_login()
        _fail(action, handle)
        if xbmcgui.Dialog().yesno(ADDON_NAME, tr(30212)) and auth.login(state):
            xbmc.executebuiltin('Container.Refresh')
    except JellyfinError as exc:
        log(f'{action} failed: {exc}', xbmc.LOGERROR)
        notify(tr(30220).format(exc), error=True)
        _fail(action, handle)


def _fail(action, handle):
    if handle < 0:
        return
    if action == 'play':
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem(offscreen=True))
    else:
        xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)


def _forget_in_kodi(item_id, played):
    """Kodi keeps its own watched state and resume position of what it played (by the plugin URL the item was
    started from): set them like Jellyfin now has them, so Kodi does not offer an old position again."""
    for url in (build_url(action='play', id=item_id), build_url(action='play', id=item_id, skin=1)):
        request = {'jsonrpc': '2.0', 'id': 1, 'method': 'Files.SetFileDetails',
                   'params': {'file': url, 'media': 'video', 'playcount': 1 if played else 0,
                              'resume': {'position': 0, 'total': 0}}}
        xbmc.executeJSONRPC(json.dumps(request))  # an error only means Kodi never played it from there


def _close(handle):
    """Actions opened from a folder item: keep the current listing and refresh it."""
    if handle >= 0:
        xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)
    xbmc.executebuiltin('Container.Refresh')


def _int(value):
    try:
        return max(0, int(value or 0))
    except ValueError:
        return 0


def _page(params):
    return _int(params.get('page'))


def _dispatch_quiet(action, params, handle, state):
    client = config.get_client(state)
    nav = Navigator(handle, client, state)
    try:
        token = params.get('reload', '')  # the skin's reload token, part of every row and menu URL
        if action == 'home_menu':
            nav.home_menu(token)
        elif client.token and params.get('view') in WIDGET_VIEWS:
            nav.widget(params.get('section'), params['view'], token)
        else:
            xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)
    except AuthError:
        log('Token rejected by server (skin request)', xbmc.LOGWARNING)
        state.clear_login()
        _fail(action, handle)
    except JellyfinError as exc:
        log(f'{action} failed: {exc}', xbmc.LOGWARNING)
        _fail(action, handle)


def _dispatch(action, params, handle, state):
    if action == 'login':
        auth.login(state)
        reload_widgets()  # skin main menu shows the libraries of the new user
        _close(handle)
        return
    if action == 'settings':
        if handle >= 0:
            xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)
        xbmc.executebuiltin(f'Addon.OpenSettings({ADDON_ID})')
        return
    if action == 'kodi':
        # Kodi entries of the skin menu (the skin opens them itself; this is the fallback)
        if handle >= 0:
            xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)
        if params.get('target') in KODI_WINDOWS:
            xbmc.executebuiltin(KODI_WINDOWS[params['target']])
        return
    if action == 'logout':
        auth.logout(state)
        reload_widgets()
        _close(handle)
        return

    client = config.get_client(state)
    if not client.token and action not in PUBLIC_ACTIONS:
        if not auth.login(state):
            _fail(action, handle)
            return
        client = config.get_client(state)

    if action == 'library_modes':
        choose_library_modes(client, state)
        reload_widgets()  # the skin's menu and rows follow the library modes (folder row or the dashboard)
        _close(handle)
        return
    if action == 'play':
        playback.play(handle, client, params['id'], _int(params.get('autoplay')), params.get('skin') == '1')
        return
    if action in ('mark_played', 'mark_unplayed'):
        client.set_played(params['id'], action == 'mark_played')  # Jellyfin also drops the resume position
        _forget_in_kodi(params['id'], action == 'mark_played')
        reload_widgets()
        xbmc.executebuiltin('Container.Refresh')
        return

    # browsing (not playback or marking above): repeat visits within minutes come from the list cache
    client.cache_token = xbmcgui.Window(10000).getProperty(WIDGET_RELOAD_PROPERTY)
    nav = Navigator(handle, client, state)
    section = params.get('section')
    if action == 'section' and section:
        nav.section_menu(section)
    elif action == 'list' and section and params.get('view') in LATEST_VIEWS:
        nav.latest(section, params['view'])
    elif action == 'list' and section:
        nav.paged(section, params.get('view', 'all'), _page(params),
                  genre=params.get('genre'), letter=params.get('letter'))
    elif action == 'genres' and section:
        nav.genres(section)
    elif action == 'letters' and section:
        nav.letters(section)
    elif action == 'folder' and params.get('id'):
        nav.folder(params['id'], _page(params))
    elif action == 'series':
        nav.series(params['id'])
    elif action == 'open' and params.get('id'):
        nav.open_item(params['id'])
    elif action == 'episodes':
        nav.episodes(params['series'], params.get('season'), _page(params))
    elif action == 'search':
        nav.search_kind('all')  # global search: every library, no film / TV show choice
    elif action == 'search_kind' and params.get('kind') in SEARCH_KINDS:
        nav.search_kind(params['kind'], section)
    elif action == 'search_new' and params.get('kind') in SEARCH_KINDS:
        nav.search_new(params['kind'], section)
    elif action == 'search_remove':
        state.remove_search(params.get('q', ''), params.get('kind'), section)
        xbmc.executebuiltin('Container.Refresh')
    elif action == 'search_results' and params.get('kind') in SEARCH_KINDS:
        nav.search_results(params.get('q', ''), params['kind'], section)
    else:
        nav.main_menu()
