# -*- coding: utf-8 -*-
"""User settings (settings.xml) and private login state (state.json in the addon profile).

The password is never stored. Only the Jellyfin access token is kept, in the addon profile
folder outside settings.xml; it can be revoked any time in the Jellyfin dashboard (Devices).
"""
import json
import os
import uuid

import xbmcaddon
import xbmcgui

from .jellyfin_api import ITEM_FIELDS, PEOPLE_FIELD, JellyfinClient
from .utils import ADDON, PROFILE_DIR, TILES_PROPERTY, log

STATE_FILE = os.path.join(PROFILE_DIR, 'state.json')

PLAYBACK_AUTO, PLAYBACK_HTTP, PLAYBACK_DIRECT = 0, 1, 2

SEARCH_HISTORY_SIZE = 20


class _LegacySettings(object):
    """Kodi 19 has no Addon.getSettings(); same interface over the older getters."""

    def getString(self, key):
        return ADDON.getSetting(key)

    def getBool(self, key):
        return ADDON.getSettingBool(key)

    def getInt(self, key):
        return ADDON.getSettingInt(key)

    def setString(self, key, value):
        ADDON.setSetting(key, value)


def reload():
    """Fresh view of the settings for the long-running service."""
    global ADDON
    ADDON = xbmcaddon.Addon()


def _settings():
    if hasattr(ADDON, 'getSettings'):
        return ADDON.getSettings()
    return _LegacySettings()


def normalize_server_url(url):
    url = (url or '').strip().rstrip('/')
    if url and '://' not in url:
        url = 'http://' + url
    return url


def server_url():
    return normalize_server_url(_settings().getString('server_url'))


def set_server_url(url):
    _settings().setString('server_url', normalize_server_url(url))


def username():
    return _settings().getString('username')


def set_username(name):
    _settings().setString('username', name or '')


def verify_ssl():
    return _settings().getBool('verify_ssl')


def page_size():
    return max(10, _settings().getInt('page_size') or 100)


def sort_order():
    return _settings().getInt('sort_order')


def playback_mode():
    return _settings().getInt('playback_mode')


def path_rules():
    s = _settings()
    return [(s.getString(f'path_from_{i}'), s.getString(f'path_to_{i}')) for i in (1, 2)]


def external_subtitles():
    return _settings().getBool('external_subs')


def skip_single_season():
    return _settings().getBool('skip_single_season')


def show_watched():
    return _settings().getBool('show_watched')


ROW_PLAY, ROW_OPEN = 0, 1


def latest_hide_watched():
    """Dashboard rows Recently added (Jellyfin's): watched films / episodes left out for every user, without
    setting it for each of them in Jellyfin (off: as Jellyfin has it, which shows them by default)."""
    return _settings().getBool('latest_hide_watched')


def row_click():
    """Skin rows (all but Continue watching): a film / episode / video tile plays it (ROW_PLAY) or opens the list
    holding it, focused on it (ROW_OPEN)."""
    return ROW_PLAY if _settings().getInt('row_click') == ROW_PLAY else ROW_OPEN


def audio_language():
    """Preferred audio language of PucekCinema playback (languages.LANGUAGES key), 0 = Kodi decides."""
    return _settings().getInt('audio_language')


def subtitle_language():
    """Preferred subtitle language (languages.LANGUAGES key), 99 = no subtitles, 0 = Kodi decides."""
    return _settings().getInt('subtitle_language')


def report_playback():
    return _settings().getBool('report_playback')


def home_tiles():
    """Home screen tiles of the PucekCinema skin: 'poster' (portrait) or 'landscape'. Setting values 2 and 3 are
    the portrait / landscape tiles of older versions (when there were variants with a dark caption bar)."""
    return 'landscape' if _settings().getInt('home_tiles') in (1, 3) else 'poster'


def publish_home_tiles():
    xbmcgui.Window(10000).setProperty(TILES_PROPERTY, home_tiles())


def autoplay_countdown():
    """Seconds before the end of an episode when the Next episode window appears."""
    return min(120, max(10, _settings().getInt('autoplay_countdown') or 30))


def hdr_custom():
    return _settings().getBool('hdr_custom')


def hdr_dolby_vision():
    return _settings().getBool('hdr_dolby_vision')


def hdr_hdr10_plus():
    return _settings().getBool('hdr_hdr10_plus')


def autoplay_limit():
    """How many episodes may start automatically in a row (0 = switched off)."""
    if not _settings().getBool('autoplay_next'):
        return 0
    return min(10, max(1, _settings().getInt('autoplay_episodes')))


def resume_from_jellyfin():
    return _settings().getBool('resume_from_jellyfin')


def load_cast():
    return _settings().getBool('load_cast')


def fuzzy_search():
    return _settings().getBool('fuzzy_search')


def label_part(part):
    """Show languages / year / genre after names in lists (`label_<part>`)."""
    return _settings().getBool(f'label_{part}')


def menu_enabled(entry):
    """Section submenu entry switched on in settings (`menu_<entry>`)."""
    return _settings().getBool(f'menu_{entry}')


def limit(entry):
    """How many items a "latest" list shows (`limit_<entry>`)."""
    return max(5, _settings().getInt(f'limit_{entry}') or 20)


class State(object):
    """Login token, device id and search history."""

    def __init__(self):
        self.data = {}
        try:
            with open(STATE_FILE, 'r', encoding='utf-8') as handle:
                self.data = json.load(handle)
        except (OSError, ValueError):
            self.data = {}
        if not self.data.get('device_id'):
            self.data['device_id'] = uuid.uuid4().hex
            self.save()

    @property
    def device_id(self):
        return self.data['device_id']

    @property
    def token(self):
        return self.data.get('token')

    @property
    def user_id(self):
        return self.data.get('user_id')

    def is_logged_in(self, server):
        return bool(self.token and self.user_id and self.data.get('server') == server)

    def set_login(self, server, user_id, user_name, token):
        self.data.update(server=server, user_id=user_id, user_name=user_name, token=token)
        self.save()

    def clear_login(self):
        for key in ('token', 'user_id', 'user_name'):
            self.data.pop(key, None)
        self.save()

    def library_modes(self):
        """{library id: 'movie' | 'series' | 'folder'} chosen in settings; missing = automatic."""
        return dict(self.data.get('library_modes') or {})

    def set_library_modes(self, modes):
        self.data['library_modes'] = dict(modes)
        self.save()

    def search_history(self):
        """[{'q': query, 'kind': 'movie' | 'series', 'section': library id or None}, ...], newest first."""
        return [e for e in self.data.get('search_history') or [] if isinstance(e, dict) and 'category' not in e]

    def add_search(self, query, kind, section=None):
        """`section` set = search inside one library (kept apart from the main search history)."""
        history = [e for e in self.search_history()
                   if not (e['kind'] == kind and e.get('section') == section and e['q'].lower() == query.lower())]
        entry = {'q': query, 'kind': kind, 'section': section}
        kept, counts = [], {}
        for item in [entry] + history:  # the last SEARCH_HISTORY_SIZE per kind and library
            group = (item['kind'], item.get('section'))
            counts[group] = counts.get(group, 0) + 1
            if counts[group] <= SEARCH_HISTORY_SIZE:
                kept.append(item)
        self.data['search_history'] = kept
        self.save()

    def remove_search(self, query, kind, section=None):
        self.data['search_history'] = [e for e in self.search_history()
                                       if (e['q'], e['kind'], e.get('section')) != (query, kind, section)]
        self.save()

    def save(self):
        os.makedirs(PROFILE_DIR, exist_ok=True)
        tmp = STATE_FILE + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as handle:
            json.dump(self.data, handle)
        try:
            os.chmod(tmp, 0o600)
        except OSError:
            pass
        os.replace(tmp, STATE_FILE)
        log('State saved')


def get_client(state):
    server = server_url()
    logged_in = state.is_logged_in(server)
    client = JellyfinClient(server, state.device_id,
                            token=state.token if logged_in else None,
                            user_id=state.user_id if logged_in else None,
                            verify_ssl=verify_ssl())
    if load_cast():
        client.fields = f'{ITEM_FIELDS},{PEOPLE_FIELD}'
    return client
