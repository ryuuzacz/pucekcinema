# -*- coding: utf-8 -*-
"""Selecting an item in a listing once Kodi shows it ("Open in its list" of the skin's tiles).

Kodi shows a plugin listing and sets its own selection (the remembered or the first item) only after the plugin
run has ended, so the plugin cannot select anything itself: it leaves a request here and the service, which keeps
running, selects the item when the list is there and keeps selecting it until the selection holds.
"""
import json
import time
from urllib.parse import urlsplit

import xbmc
import xbmcgui

from .utils import ADDON_ID, log, parse_params

FOCUS_PROPERTY = f'{ADDON_ID}.focus'
TIMEOUT = 15     # seconds after the request
HOLD = 3         # checks in a row the item has to stay selected
GUARD = 3        # seconds after that: Kodi putting the selection back to the top is undone (a user moving it is not)
VIEW_CONTROLS = (50, 51, 52, 53, 54, 55, 500, 501, 502)  # lists of the video window views (Estuary, most skins)
LIST_VIEWS = (50, 55)  # vertical lists (List, Wide list): Down / Up move the selection by one item
VIDEO_WINDOW = 10025


def request(item_id):
    """Called by the plugin listing the page that holds the item (action=open)."""
    xbmcgui.Window(10000).setProperty(FOCUS_PROPERTY, json.dumps({'id': item_id, 'time': time.time()}))


def _item_id(path):
    return parse_params(urlsplit(path).query).get('id') if path else None


class FocusFollower(object):
    """Service side: step() several times a second."""

    def __init__(self):
        self.item_id, self.since, self.held, self.attempts, self.guard_until = None, 0.0, 0, 0, 0.0

    def step(self):
        home = xbmcgui.Window(10000)
        raw = home.getProperty(FOCUS_PROPERTY)
        if raw:
            home.clearProperty(FOCUS_PROPERTY)
            try:
                data = json.loads(raw)
            except ValueError:
                data = {}
            self.item_id, self.since, self.held, self.attempts = data.get('id'), data.get('time', 0.0), 0, 0
            self.guard_until = 0.0
        if not self.item_id:
            return
        now = time.time()
        if self.guard_until and now > self.guard_until:
            self.item_id = None
            return
        if not self.guard_until and now - self.since > TIMEOUT:
            log(f'Item {self.item_id} could not be selected ({self.attempts} attempts)', xbmc.LOGWARNING)
            self.item_id = None
            return
        if xbmcgui.getCurrentWindowId() != VIDEO_WINDOW:
            # still on the home screen (its tile holds the same id) or in a dialog: wait for the list window
            self.held = 0
            return
        path = xbmc.getInfoLabel('Container.FolderPath')
        params = parse_params(urlsplit(path).query) if path.startswith(f'plugin://{ADDON_ID}') else {}
        if (params.get('action'), params.get('id')) != ('open', self.item_id) \
                or xbmc.getCondVisibility('Container.IsUpdating'):
            if self.guard_until:
                self.item_id = None  # the user went elsewhere
            self.held = 0
            return
        control, focused, visible = _view_control()
        if control is None:
            return
        selected = xbmc.getInfoLabel(f'Container({control}).ListItem.FileNameAndPath')
        if _item_id(selected) == self.item_id and 'action=play' in selected:  # the list's entry, not a tile
            self.held += 1
            if self.held >= HOLD and not self.guard_until:
                log(f'Item {self.item_id} selected in list {control} ({self.attempts} attempts)', xbmc.LOGINFO)
                self.guard_until = now + GUARD
            return
        if self.guard_until:
            top = {xbmc.getInfoLabel(f'Container({control}).ListItemAbsolute({i}).FileNameAndPath') for i in (0, 1)}
            if selected not in top:
                self.item_id = None  # the user moved the cursor
                return
            log(f'Kodi moved the selection back to the top, selecting {self.item_id} again', xbmc.LOGINFO)
        self.held = 0
        count = int(xbmc.getInfoLabel(f'Container({control}).NumItems') or 0)
        # absolute positions may include the '..' item
        paths = [xbmc.getInfoLabel(f'Container({control}).ListItemAbsolute({i}).FileNameAndPath') for i in range(count + 2)]
        index = next((i for i, path in enumerate(paths) if _item_id(path) == self.item_id), None)
        if index is None:
            return  # Kodi has not filled the list yet
        self.attempts += 1
        log(f'Selecting {self.item_id}: list {control} (focused {focused}, visible {visible}), position {index} '
            f'of {count}, selected now {selected!r}, attempt {self.attempts}', xbmc.LOGINFO)
        current = paths.index(selected) if selected in paths else None
        if self.attempts > 2 and control in LIST_VIEWS and focused == control and current is not None:
            # SetFocus did not take: move the selection like the remote does
            direction = 'Down' if index > current else 'Up'
            for _ in range(abs(index - current)):
                xbmc.executebuiltin(f'Action({direction})')
            return
        xbmc.executebuiltin(f'SetFocus({control},{index},absolute)')


def _view_control():
    """(list of the current view, focused control, visible view lists). The video window obeys SetFocus with a
    position only for the list of its current view (for another view list it just focuses the current one), and
    after loading Kodi focuses that list itself; the visible lists are the fallback while focus is elsewhere."""
    try:
        focused = xbmcgui.Window(VIDEO_WINDOW).getFocusId()
    except RuntimeError:  # nothing focused
        focused = None
    visible = [c for c in VIEW_CONTROLS if xbmc.getCondVisibility(f'Control.IsVisible({c})')]
    if focused in VIEW_CONTROLS:
        return focused, focused, visible
    return (visible[0] if visible else None), focused, visible
