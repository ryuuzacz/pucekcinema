# -*- coding: utf-8 -*-
"""Typo-tolerant title search on top of Jellyfin's exact search.

Titles of a library are downloaded once (names only) and cached for an hour; the query is
compared without diacritics and case, word by word, so a typo, swapped letters or an
unfinished word still finds the title.
"""
import json
import os
import re
import time
import unicodedata
from difflib import SequenceMatcher

from .utils import PROFILE_DIR, log

CACHE_TTL = 3600
MIN_SCORE = 0.72


def normalize(text):
    text = unicodedata.normalize('NFKD', text or '').encode('ascii', 'ignore').decode('ascii').lower()
    return ' '.join(re.sub(r'[^a-z0-9]+', ' ', text).split())


def _word_score(word, title_words):
    best = 0.0
    for candidate in title_words:
        if len(word) >= 3 and candidate.startswith(word):
            return 1.0
        best = max(best, SequenceMatcher(None, word, candidate).ratio())
    return best


def score(query, title):
    """0..1 similarity of a (normalized) query to a title."""
    title = normalize(title)
    if not query or not title:
        return 0.0
    if query in title:
        return 1.0
    whole = SequenceMatcher(None, query, title).ratio()
    title_words = title.split()
    words = [_word_score(word, title_words) for word in query.split()]
    return max(whole, sum(words) / len(words))


def _titles(client, library_id, item_type):
    path = os.path.join(PROFILE_DIR, f'titles_{library_id}_{item_type}.json')
    try:
        if time.time() - os.path.getmtime(path) < CACHE_TTL:
            with open(path, 'r', encoding='utf-8') as handle:
                return json.load(handle)
    except (OSError, ValueError):
        pass
    titles = client.titles(library_id, item_type)
    try:
        os.makedirs(PROFILE_DIR, exist_ok=True)
        with open(path, 'w', encoding='utf-8') as handle:
            json.dump(titles, handle)
    except OSError as exc:
        log(f'Cannot write title cache: {exc}')
    return titles


def search(client, library_ids, item_type, query, limit, exclude=()):
    """Ids of titles similar to `query`, best first."""
    query = normalize(query)
    if not query:
        return []
    scored = {}
    for library_id in library_ids:
        for title in _titles(client, library_id, item_type):
            if title['Id'] in exclude:
                continue
            best = max(score(query, title['Name']), score(query, title['OriginalTitle']))
            if best >= MIN_SCORE and best > scored.get(title['Id'], 0):
                scored[title['Id']] = best
    return sorted(scored, key=scored.get, reverse=True)[:limit]
