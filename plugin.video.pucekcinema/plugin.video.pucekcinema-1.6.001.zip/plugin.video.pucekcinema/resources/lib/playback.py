# -*- coding: utf-8 -*-
"""Playback: resolve a Jellyfin item to a direct SMB/NFS path or the original-file HTTP stream.

Kodi's own VideoPlayer always plays the original file, so every embedded audio and subtitle
track stays selectable in Kodi. Nothing is transcoded on the server.
"""
import os
import re
import shutil

import xbmc
import xbmcgui
import xbmcplugin

from . import config, hdr, reporting
from .jellyfin_api import JellyfinError
from .listitems import build_item, resume_point
from .utils import TEMP_DIR, log, notify, tr

MIME_TYPES = {
    'mkv': 'video/x-matroska', 'webm': 'video/webm', 'mp4': 'video/mp4', 'm4v': 'video/mp4',
    'mov': 'video/mp4', 'avi': 'video/x-msvideo', 'ts': 'video/mp2t', 'm2ts': 'video/mp2t',
    'mpegts': 'video/mp2t', 'wmv': 'video/x-ms-wmv', 'asf': 'video/x-ms-asf', 'flv': 'video/x-flv',
}

# Jellyfin subtitle codec -> format requested from the server (= file extension for Kodi)
TEXT_SUBTITLES = {'subrip': 'srt', 'srt': 'srt', 'ass': 'ass', 'ssa': 'ssa', 'webvtt': 'vtt', 'vtt': 'vtt'}

SUBTITLE_DIR = os.path.join(TEMP_DIR, 'subtitles')


def map_direct_path(path, rules):
    """Server file path -> path Kodi can open (smb://, nfs://, ...), or None when no rule matches."""
    if not path:
        return None
    if path.lower().startswith(('smb://', 'nfs://')):
        return path
    unc = path.startswith('\\\\')
    normalized = path.replace('\\', '/')
    for source, target in rules:
        source, target = (source or '').strip(), (target or '').strip()
        if not source or not target:
            continue
        prefix = source.replace('\\', '/').rstrip('/')
        windows = unc or (len(prefix) > 1 and prefix[1] == ':')
        haystack, needle = (normalized.lower(), prefix.lower()) if windows else (normalized, prefix)
        if haystack == needle or haystack.startswith(needle + '/'):
            rest = normalized[len(prefix):].lstrip('/')
            return target.rstrip('/') + '/' + rest
    if unc:
        return 'smb://' + normalized.lstrip('/')
    return None


def _direct_path(source):
    path = source.get('Path')
    if (source.get('Protocol') or '').lower() == 'http' and path and path.lower().startswith(('http://', 'https://')):
        return path
    return map_direct_path(path, config.path_rules())


def _choose_source(sources):
    if len(sources) == 1:
        return sources[0]
    labels = [s.get('Name') or s.get('Container') or s.get('Id') for s in sources]
    index = xbmcgui.Dialog().select(tr(30216), labels)
    return sources[index] if index >= 0 else None


def _external_subtitles(client, item_id, source):
    shutil.rmtree(SUBTITLE_DIR, ignore_errors=True)
    files = []
    for stream in source.get('MediaStreams') or []:
        if stream.get('Type') != 'Subtitle' or not stream.get('IsExternal'):
            continue
        fmt = TEXT_SUBTITLES.get((stream.get('Codec') or '').lower())
        if not fmt:
            continue
        language = re.sub(r'[^a-z]', '', (stream.get('Language') or '').lower()) or 'und'
        flags = '.forced' if stream.get('IsForced') else ''
        try:
            data = client.download(client.subtitle_url(item_id, source['Id'], stream['Index'], fmt))
        except JellyfinError as exc:
            log(f"Subtitle {stream.get('Index')} download failed: {exc}", xbmc.LOGWARNING)
            continue
        os.makedirs(SUBTITLE_DIR, exist_ok=True)
        # Kodi reads the language and "forced" flag from the file name.
        target = os.path.join(SUBTITLE_DIR, f"subtitle.{stream['Index']}.{language}{flags}.{fmt}")
        with open(target, 'wb') as handle:
            handle.write(data)
        files.append(target)
    return files


def _fail(handle):
    xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem(offscreen=True))


def _kodi_major():
    try:
        return int(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
    except ValueError:
        return 0


def _clock(seconds):
    seconds = int(seconds)
    return f'{seconds // 3600}:{seconds // 60 % 60:02d}:{seconds % 60:02d}'


def _skin_resume(item):
    """Start position for a tile of the skin's home screen: Kodi before 21 plays it as a bare path, without its
    "Resume from ..." dialog (and the stop at the start would then wipe the position in Jellyfin), so ask here.
    Kodi 21 asks itself. Seconds to start from (0 = from the start), None when the dialog was cancelled."""
    resume = resume_point(item)
    if not resume or _kodi_major() >= 21:
        return 0.0
    choice = xbmcgui.Dialog().contextmenu([tr(30272).format(_clock(resume[0])), tr(30273)])
    if choice < 0:
        return None
    return resume[0] if choice == 0 else 0.0


def play(handle, client, item_id, chain=0, from_skin=False):
    """`chain` > 0: episode started automatically after the previous one; no dialogs, from the start.
    `from_skin`: started from a tile of the skin's home screen (see _skin_resume)."""
    item = client.item(item_id)
    start = _skin_resume(item) if from_skin and not chain else 0.0
    if start is None:
        _fail(handle)
        return
    sources = [s for s in item.get('MediaSources') or [] if s.get('Id')]
    if not sources:
        notify(tr(30217), error=True)
        _fail(handle)
        return
    source = sources[0] if chain else _choose_source(sources)
    if source is None:
        _fail(handle)
        return

    mode = config.playback_mode()
    path = _direct_path(source) if mode != config.PLAYBACK_HTTP else None
    if path is None and mode == config.PLAYBACK_DIRECT:
        notify(tr(30218), error=True)
        _fail(handle)
        return

    list_item = build_item(client, item, show_watched=False)
    if start:
        list_item.setProperty('StartOffset', str(start))
    if path:
        log(f'Playing {item_id} from direct path', xbmc.LOGINFO)
        list_item.setPath(path)
    else:
        log(f'Playing {item_id} as original-file HTTP stream', xbmc.LOGINFO)
        container = (source.get('Container') or '').split(',')[0].strip().lower()
        list_item.setPath(client.stream_url(item_id, source['Id'], container) + '|' + client.kodi_headers())
        if container in MIME_TYPES:
            list_item.setMimeType(MIME_TYPES[container])
            list_item.setContentLookup(False)
        if config.external_subtitles():
            subtitles = _external_subtitles(client, item_id, source)
            if subtitles:
                list_item.setSubtitles(subtitles)
    if not hdr.apply_for_playback():
        notify(tr(30186), error=True)
    reporting.announce(item, source['Id'], 'DirectPlay' if path else 'DirectStream', chain, start)
    xbmcplugin.setResolvedUrl(handle, True, list_item)

