# -*- coding: utf-8 -*-
"""Login (Quick Connect or user name + password) and logout."""
import xbmc
import xbmcgui

from . import config
from .jellyfin_api import AuthError, JellyfinClient, JellyfinError
from .utils import ADDON_NAME, log, notify, tr

QUICK_CONNECT_TIMEOUT = 300
QUICK_CONNECT_POLL = 2


def login(state):
    dialog = xbmcgui.Dialog()
    server = config.server_url()
    if not server:
        server = config.normalize_server_url(dialog.input(tr(30200), defaultt='http://'))
        if not server or server == 'http:':
            return False
        config.set_server_url(server)

    client = JellyfinClient(server, state.device_id, verify_ssl=config.verify_ssl())
    try:
        info = client.public_info()
    except JellyfinError as exc:
        dialog.ok(ADDON_NAME, f'{tr(30207)}\n{server}\n{exc}')
        return False
    log(f"Server {info.get('ServerName')} {info.get('Version')}", xbmc.LOGINFO)

    quick_connect = client.quick_connect_enabled()
    methods = ([tr(30202)] if quick_connect else []) + [tr(30203)]
    choice = dialog.select(tr(30201), methods) if len(methods) > 1 else 0
    if choice < 0:
        return False

    try:
        if quick_connect and choice == 0:
            result = _quick_connect(client)
        else:
            result = _password_login(client)
    except AuthError:
        dialog.ok(ADDON_NAME, tr(30206))
        return False
    except JellyfinError as exc:
        dialog.ok(ADDON_NAME, f'{tr(30206)}\n{exc}')
        return False
    if not result or not result.get('AccessToken'):
        return False

    user = result.get('User') or {}
    state.set_login(server, user.get('Id'), user.get('Name'), result['AccessToken'])
    config.set_username(user.get('Name'))
    notify(tr(30205).format(user.get('Name') or ''))
    return True


def _password_login(client):
    dialog = xbmcgui.Dialog()
    name = dialog.input(tr(30103), defaultt=config.username())
    if not name:
        return None
    password = dialog.input(tr(30204), option=xbmcgui.ALPHANUM_HIDE_INPUT)
    return client.authenticate_by_name(name, password)


def _quick_connect(client):
    started = client.quick_connect_initiate()
    secret, code = started.get('Secret'), started.get('Code')
    if not secret:
        raise JellyfinError(tr(30210))

    message = tr(30208).format(code)
    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, message)
    monitor = xbmc.Monitor()
    try:
        waited = 0
        while waited < QUICK_CONNECT_TIMEOUT:
            if progress.iscanceled() or monitor.waitForAbort(QUICK_CONNECT_POLL):
                return None
            waited += QUICK_CONNECT_POLL
            progress.update(int(waited * 100 / QUICK_CONNECT_TIMEOUT), f'{message}\n{tr(30209)}')
            if client.quick_connect_state(secret).get('Authenticated'):
                return client.authenticate_quick_connect(secret)
    finally:
        progress.close()
    xbmcgui.Dialog().ok(ADDON_NAME, tr(30221))
    return None


def logout(state):
    client = config.get_client(state)
    if client.token:
        try:
            client.logout()
        except JellyfinError as exc:
            log(f'Logout request failed: {exc}', xbmc.LOGWARNING)
    state.clear_login()
    notify(tr(30211))
