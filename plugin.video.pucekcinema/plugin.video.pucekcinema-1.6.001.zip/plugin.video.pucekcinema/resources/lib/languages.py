# -*- coding: utf-8 -*-
"""Preferred audio and subtitle language for PucekCinema playback (add-on settings, per Kodi device).

Kodi has such preferences only globally and Jellyfin's apply only to its own players, so the service picks the
streams itself when a PucekCinema playback starts: Kodi already knows every embedded and external stream with its
language (Jellyfin's external subtitles carry the language in their file name, see playback).
"""
import json

import xbmc

from . import config
from .utils import log

# setting value -> (label, language codes as Kodi reports them: ISO 639-2/B and /T, ISO 639-1); 0 = leave it to
# Kodi. Values are stored in the settings, so new languages get new numbers.
LANGUAGES = {
    1: (30251, ('cze', 'ces', 'cs')),
    2: (30252, ('slo', 'slk', 'sk')),
    3: (30253, ('eng', 'en')),
    4: (30254, ('ger', 'deu', 'de')),
    5: (30255, ('pol', 'pl')),
    6: (30256, ('fre', 'fra', 'fr')),
    7: (30257, ('spa', 'es')),
    8: (30258, ('ita', 'it')),
    9: (30259, ('rus', 'ru')),
    10: (30260, ('jpn', 'ja')),
}
SUBTITLES_OFF = 99


def _rpc(method, params=None):
    request = {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params or {}}
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps(request)) or '{}').get('result')
    except (ValueError, AttributeError):
        return None


def _codes(value):
    return LANGUAGES[value][1] if value in LANGUAGES else ()


def _matches(stream, codes):
    return (stream.get('language') or '').lower() in codes


def _video_player():
    for player in _rpc('Player.GetActivePlayers') or []:
        if isinstance(player, dict) and player.get('type') == 'video':
            return player.get('playerid')
    return None


def apply():
    """Switches the playing video to the preferred audio and subtitle language (when it has them)."""
    audio, subtitles = config.audio_language(), config.subtitle_language()
    if not audio and not subtitles:
        return
    player = _video_player()
    if player is None:
        return
    props = _rpc('Player.GetProperties', {'playerid': player, 'properties': [
        'audiostreams', 'currentaudiostream', 'subtitles', 'currentsubtitle', 'subtitleenabled']}) or {}
    current_audio = props.get('currentaudiostream') or {}
    codes = _codes(audio)
    if codes and not _matches(current_audio, codes):
        stream = next((s for s in props.get('audiostreams') or [] if _matches(s, codes)), None)
        if stream:
            _rpc('Player.SetAudioStream', {'playerid': player, 'stream': stream['index']})
            current_audio = stream
            log(f"Audio switched to {stream.get('language')} ({stream.get('name')})", xbmc.LOGINFO)
    if subtitles == SUBTITLES_OFF:
        if props.get('subtitleenabled'):
            _rpc('Player.SetSubtitle', {'playerid': player, 'subtitle': 'off'})
        return
    codes = _codes(subtitles)
    if not codes or _matches(current_audio, codes):
        return  # nothing chosen, or the film already speaks the subtitle language: Kodi's choice stays
    streams = [s for s in props.get('subtitles') or [] if _matches(s, codes)]
    # full subtitles before forced ones (forced = only the foreign parts)
    streams.sort(key=lambda s: bool(s.get('isforced')) or 'forced' in (s.get('name') or '').lower())
    if streams:
        _rpc('Player.SetSubtitle', {'playerid': player, 'subtitle': streams[0]['index'], 'enable': True})
        log(f"Subtitles switched to {streams[0].get('language')} ({streams[0].get('name')})", xbmc.LOGINFO)
