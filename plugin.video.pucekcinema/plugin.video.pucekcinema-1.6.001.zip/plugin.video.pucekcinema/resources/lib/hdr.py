# -*- coding: utf-8 -*-
"""Allowed HDR formats only for PucekCinema playback (Kodi 21+ on Android / webOS).

Kodi setting `videoplayer.allowedhdrformats` is a list of the allowed *dynamic* formats:
0 = Dolby Vision, 1 = HDR10+. HDR10 (the static base layer) cannot be switched off in Kodi,
so there is no switch for it. With Dolby Vision disallowed, a Dolby Vision profile 8 file
plays as HDR10.

Before PucekCinema playback the original value is saved to the addon profile, the user's
choice is set and verified. After playback (stop, end, error) the service restores the
original value unless the user changed the Kodi setting in the meantime. A leftover saved
value (crash, Kodi killed) is restored by the service when Kodi idles or starts again.
"""
import json
import os
import time

import xbmc

from . import config
from .utils import PROFILE_DIR, log

KODI_SETTING = 'videoplayer.allowedhdrformats'
DOLBY_VISION, HDR10_PLUS = 0, 1
RESTORE_FILE = os.path.join(PROFILE_DIR, 'hdr_restore.json')
IDLE_RESTORE_AFTER = 30  # seconds after the last apply; a starting playback is never restored under it


class HdrError(Exception):
    pass


def _rpc(method, params):
    request = {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params}
    try:
        response = json.loads(xbmc.executeJSONRPC(json.dumps(request)) or '{}')
    except ValueError:
        response = {}
    if 'result' not in response:
        raise HdrError(str(response.get('error') or 'no result'))
    return response['result']


def read():
    """Current Kodi value as a sorted list, or None when this Kodi has no such setting."""
    try:
        value = _rpc('Settings.GetSettingValue', {'setting': KODI_SETTING}).get('value')
    except HdrError:
        return None
    return sorted(int(v) for v in value) if isinstance(value, list) else None


def write(value):
    _rpc('Settings.SetSettingValue', {'setting': KODI_SETTING, 'value': sorted(value)})
    if read() != sorted(value):
        raise HdrError('value not applied')


def wanted():
    """Formats allowed by the PucekCinema switches, or None when the feature is off."""
    if not config.hdr_custom():
        return None
    formats = []
    if config.hdr_dolby_vision():
        formats.append(DOLBY_VISION)
    if config.hdr_hdr10_plus():
        formats.append(HDR10_PLUS)
    return formats


def _saved():
    try:
        with open(RESTORE_FILE, 'r', encoding='utf-8') as handle:
            return json.load(handle)
    except (OSError, ValueError):
        return None


def _save(original, applied):
    os.makedirs(PROFILE_DIR, exist_ok=True)
    tmp = RESTORE_FILE + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as handle:
        json.dump({'original': original, 'applied': applied, 'time': time.time()}, handle)
    os.replace(tmp, RESTORE_FILE)


def _forget():
    try:
        os.remove(RESTORE_FILE)
    except OSError:
        pass


def pending():
    return _saved() is not None


def apply_for_playback():
    """Before PucekCinema playback. Returns False when the change failed (playback continues unchanged)."""
    formats = wanted()
    if formats is None:
        return True
    current = read()
    if current is None:
        log(f'{KODI_SETTING} is not available on this Kodi; HDR switches have no effect', xbmc.LOGWARNING)
        return True
    saved = _saved()
    if saved and current == saved['applied']:
        original = saved['original']        # still ours (e.g. next episode): keep the real original
    else:
        original = current                  # first playback, or the user changed Kodi meanwhile
    if current == formats:
        if saved:
            _save(original, formats)        # refresh the time, nothing to switch
        return True
    _save(original, formats)                # persist before touching Kodi (crash safety)
    try:
        write(formats)
    except HdrError as exc:
        log(f'HDR change failed: {exc}', xbmc.LOGERROR)
        try:
            write(original)
        except HdrError:
            pass
        _forget()
        return False
    log(f'HDR formats for PucekCinema: {formats} (Kodi had {original})', xbmc.LOGINFO)
    return True


def restore():
    """After PucekCinema playback / on recovery: put back the original Kodi value once."""
    saved = _saved()
    if not saved:
        return
    current = read()
    if current is not None and current == saved['applied'] and current != saved['original']:
        try:
            write(saved['original'])
            log(f"HDR formats restored to {saved['original']}", xbmc.LOGINFO)
        except HdrError as exc:
            log(f'HDR restore failed: {exc}', xbmc.LOGERROR)
            return  # keep the file, the service tries again
    elif current != saved['applied']:
        log('HDR setting was changed in Kodi meanwhile; leaving it as it is', xbmc.LOGINFO)
    _forget()


def restore_if_idle(playing):
    """Service safety net: leftover value while nothing plays (crash, Kodi restart, failed next episode)."""
    saved = _saved()
    if saved and not playing and time.time() - saved.get('time', 0) >= IDLE_RESTORE_AFTER:
        restore()
