# -*- coding: utf-8 -*-
from resources.lib import reporting

if __name__ == '__main__':
    reporting.run_service()
