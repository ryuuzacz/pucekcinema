# -*- coding: utf-8 -*-
"""Short-lived disk cache of Jellyfin list answers used while browsing (library lists, seasons, episodes).

Going back and forth in Kodi runs the plugin again for every folder; with the cache the same list does not
ask Jellyfin again for a few minutes. An answer is valid for LIST_TTL seconds and only for the same token
(the skin's reload token, renewed after playback, marking watched and login), so watched marks stay right.
Playback never uses it.
"""
import hashlib
import json
import os
import random
import time

from .utils import PROFILE_DIR

CACHE_DIR = os.path.join(PROFILE_DIR, 'cache')
LIST_TTL = 300
PRUNE_AFTER = 24 * 3600


def _path(key):
    return os.path.join(CACHE_DIR, hashlib.sha1(key.encode('utf-8')).hexdigest() + '.json')


def get(key, token):
    try:
        with open(_path(key), 'r', encoding='utf-8') as handle:
            entry = json.load(handle)
    except (OSError, ValueError):
        return None
    if entry.get('token') != token or time.time() - entry.get('time', 0) > LIST_TTL:
        return None
    return entry.get('data')


def put(key, token, data):
    os.makedirs(CACHE_DIR, exist_ok=True)
    path = _path(key)
    tmp = f'{path}.{os.getpid()}.tmp'
    with open(tmp, 'w', encoding='utf-8') as handle:
        json.dump({'time': time.time(), 'token': token, 'data': data}, handle)
    os.replace(tmp, path)
    if random.random() < 0.05:
        prune()


def prune():
    """Removes answers older than a day (the folder would otherwise only grow)."""
    now = time.time()
    try:
        names = os.listdir(CACHE_DIR)
    except OSError:
        return
    for name in names:
        path = os.path.join(CACHE_DIR, name)
        try:
            if now - os.path.getmtime(path) > PRUNE_AFTER:
                os.remove(path)
        except OSError:
            pass
