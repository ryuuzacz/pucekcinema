# -*- coding: utf-8 -*-
"""Shared helpers: addon info, localization, logging, plugin URLs."""
import os
from urllib.parse import parse_qsl, urlencode

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_VERSION = ADDON.getAddonInfo('version')
ADDON_ICON = ADDON.getAddonInfo('icon')
ADDON_FANART = ADDON.getAddonInfo('fanart')
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
MEDIA_DIR = os.path.join(ADDON_PATH, 'resources', 'media')
PROFILE_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
TEMP_DIR = xbmcvfs.translatePath(f'special://temp/{ADDON_ID}/')


# Home window property the PucekCinema skin appends to its row URLs; a new value makes Kodi reload the rows
WIDGET_RELOAD_PROPERTY = f'{ADDON_ID}.widget_reload'


# Home window properties telling the PucekCinema skin how to draw the home screen rows:
# tile shape ('poster' / 'landscape') and caption ('bar' = in a dark panel, 'plain' = just text under the image)
TILES_PROPERTY = f'{ADDON_ID}.tiles'
CAPTION_PROPERTY = f'{ADDON_ID}.caption'


def reload_widgets():
    import time
    xbmcgui.Window(10000).setProperty(WIDGET_RELOAD_PROPERTY, str(int(time.time())))


def tr(string_id):
    return ADDON.getLocalizedString(string_id)


def log(message, level=xbmc.LOGDEBUG):
    xbmc.log(f'[{ADDON_ID}] {message}', level)


def build_url(**params):
    query = urlencode({k: v for k, v in params.items() if v is not None})
    return f'plugin://{ADDON_ID}/?{query}'


def parse_params(query):
    return dict(parse_qsl((query or '').lstrip('?')))


def notify(message, error=False, time=4000):
    icon = xbmcgui.NOTIFICATION_ERROR if error else ADDON_ICON
    xbmcgui.Dialog().notification(ADDON_NAME, message, icon, time)
