# -*- coding: utf-8 -*-
"""Selecting an item in a listing once Kodi shows it ("Open in its list" of the skin's tiles).

Kodi shows a plugin listing and sets its own selection (the remembered or the first item) only after the plugin
run has ended, so the plugin cannot select anything itself: it leaves a request here and the service, which keeps
running, selects the item when the list is there and keeps selecting it until the selection holds.

The tile opens action=open&id=<item>, a URL without folders: Kodi's way back ('..', Back) from it is the add-on's
main menu. So the service first puts the list's path URL in its place (Container.Update(<path>,replace) rebuilds
Kodi's history from the path's parent folders: season, show, all shows, the library menu) and selects there.
"""
import json
import time
from urllib.parse import urlsplit

import xbmc
import xbmcgui

from .utils import ADDON_ID, log, parse_params

FOCUS_PROPERTY = f'{ADDON_ID}.focus'
TIMEOUT = 15     # seconds after the request
HOLD = 3         # checks in a row the item has to stay selected
GUARD = 1.5      # seconds after that: Kodi putting the selection back to the top is undone (a user moving it is not)
VIEW_CONTROLS = (50, 51, 52, 53, 54, 55, 500, 501, 502)  # lists of the video window views (Estuary, most skins)
LIST_VIEWS = (50, 55)  # vertical lists (List, Wide list): Down / Up move the selection by one item
VIDEO_WINDOW = 10025


def request(item_id, path=None, opened=None):
    """Called by the plugin listing the page that holds the item (action=open&id=<opened>): item_id is selected
    (None: nothing, a show opens its seasons), path is the list's path URL put in place of action=open first."""
    xbmcgui.Window(10000).setProperty(FOCUS_PROPERTY, json.dumps(
        {'id': item_id, 'path': path, 'opened': opened or item_id, 'time': time.time()}))


def _is_opened(path, item_id):
    """The window still shows the tile's URL (action=open&id=<item>)."""
    params = parse_params(urlsplit(path).query) if path.startswith(f'plugin://{ADDON_ID}') else {}
    return (params.get('action'), params.get('id')) == ('open', item_id)


def _same_path(first, second):
    return first.rstrip('/') == second.rstrip('/')


def _is_entry(path, item_id):
    """The list entry of the item: its play URL. The home screen tile and the list's '..' entry carry
    action=open with the same id."""
    params = parse_params(urlsplit(path).query) if path else {}
    return params.get('action') == 'play' and params.get('id') == item_id


class FocusFollower(object):
    """Service side: step() several times a second."""

    def __init__(self):
        self.item_id, self.since, self.held, self.attempts, self.guard_until = None, 0.0, 0, 0, 0.0
        self.path, self.opened, self.replaced = None, None, False

    def _stop(self):
        self.item_id = self.path = None

    def step(self):
        home = xbmcgui.Window(10000)
        raw = home.getProperty(FOCUS_PROPERTY)
        if raw:
            home.clearProperty(FOCUS_PROPERTY)
            try:
                data = json.loads(raw)
            except ValueError:
                data = {}
            self.item_id, self.since, self.held, self.attempts = data.get('id'), data.get('time', 0.0), 0, 0
            self.path, self.opened, self.replaced = data.get('path'), data.get('opened') or self.item_id, False
            self.guard_until = 0.0
        if not (self.item_id or self.path):
            return
        now = time.time()
        if self.guard_until and now > self.guard_until:
            self._stop()
            return
        if not self.guard_until and now - self.since > TIMEOUT:
            log(f'Item {self.item_id} could not be selected ({self.attempts} attempts)', xbmc.LOGWARNING)
            self._stop()
            return
        if xbmcgui.getCurrentWindowId() != VIDEO_WINDOW:
            # still on the home screen (its tile holds the same id) or in a dialog: wait for the list window
            self.held = 0
            return
        path = xbmc.getInfoLabel('Container.FolderPath')
        if xbmc.getCondVisibility('Container.IsUpdating'):
            if self.guard_until:
                self._stop()  # the user went elsewhere
            self.held = 0
            return
        if self.path and not self.replaced:
            if _is_opened(path, self.opened):  # the tile's list is there: the path URL with its way back instead
                xbmc.executebuiltin(f'Container.Update({self.path},replace)')
                self.replaced = True
            return
        if not (_same_path(path, self.path) if self.path else _is_opened(path, self.item_id)):
            if self.guard_until or (self.replaced and not _is_opened(path, self.opened)):
                self._stop()  # the user went elsewhere
            self.held = 0
            return
        if not self.item_id:  # a show: its seasons, nothing to select
            self._stop()
            return
        control, focused, visible = _view_control()
        if control is None:
            return
        selected = xbmc.getInfoLabel(f'Container({control}).ListItem.FileNameAndPath')
        if _is_entry(selected, self.item_id):  # the list's entry, not the home screen tile or '..'
            self.held += 1
            if self.held >= HOLD and not self.guard_until:
                log(f'Item {self.item_id} selected in list {control} ({self.attempts} attempts)', xbmc.LOGINFO)
                self.guard_until = now + GUARD
            return
        count = int(xbmc.getInfoLabel(f'Container({control}).NumItems') or 0)
        # absolute positions may include the '..' item
        paths = [xbmc.getInfoLabel(f'Container({control}).ListItemAbsolute({i}).FileNameAndPath') for i in range(count + 2)]
        # the item's own entry (it plays); '..' may carry the list's own URL (action=open&id=<the same item>)
        index = next((i for i, path in enumerate(paths) if _is_entry(path, self.item_id)), None)
        if self.guard_until:
            # Kodi's reset jumps from deep in the list to its top; the user moves by one (Up from the second
            # item, Down from the last one wrapping around): left alone
            current = paths.index(selected) if selected in paths else None
            last = max((i for i, path in enumerate(paths) if path), default=0)
            if index is None or current is None or current > 1 or index <= 2 or index >= last:
                self._stop()
                return
            log(f'Kodi moved the selection back to the top, selecting {self.item_id} again', xbmc.LOGINFO)
        self.held = 0
        if index is None:
            return  # Kodi has not filled the list yet
        self.attempts += 1
        log(f'Selecting {self.item_id}: list {control} (focused {focused}, visible {visible}), position {index} '
            f'of {count}, selected now {selected!r}, attempt {self.attempts}', xbmc.LOGINFO)
        current = paths.index(selected) if selected in paths else None
        if self.attempts > 2 and control in LIST_VIEWS and focused == control and current is not None:
            # SetFocus did not take: move the selection like the remote does
            direction = 'Down' if index > current else 'Up'
            for _ in range(abs(index - current)):
                xbmc.executebuiltin(f'Action({direction})')
            return
        xbmc.executebuiltin(f'SetFocus({control},{index},absolute)')


def _view_control():
    """(list of the current view, focused control, visible view lists). The video window obeys SetFocus with a
    position only for the list of its current view (for another view list it just focuses the current one), and
    after loading Kodi focuses that list itself; the visible lists are the fallback while focus is elsewhere."""
    try:
        focused = xbmcgui.Window(VIDEO_WINDOW).getFocusId()
    except RuntimeError:  # nothing focused
        focused = None
    visible = [c for c in VIEW_CONTROLS if xbmc.getCondVisibility(f'Control.IsVisible({c})')]
    if focused in VIEW_CONTROLS:
        return focused, focused, visible
    return (visible[0] if visible else None), focused, visible
